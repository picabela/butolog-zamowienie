<?php
// /zamowienie/fetch_label.php

// Wczytaj konfigurację (potrzebne do get_setting, jeśli będziemy chcieli token z bazy)
// Na razie token jest wpisany na stałe poniżej dla prostoty.
require_once 'includes/db.php'; // Potrzebne do get_setting i $pdo
require_once 'includes/functions.php'; // Potrzebne do log_message, get_setting, get_active_setting

// === KONFIGURACJA INPOST (SANDBOX) ===
// --- TWÓJ TOKEN WSTAWIONY PONIŻEJ ---
$inpost_token = "eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJkVzROZW9TeXk0OHpCOHg4emdZX2t5dFNiWHY3blZ0eFVGVFpzWV9TUFA4In0.eyJleHAiOjIwNTc5NTk5MTcsImlhdCI6MTc0MjU5OTkxNywianRpIjoiOGZjMWZiNmQtNTJkOS00ZDNkLTkxZWQtNTA1YTU3MGNmODA3IiwiaXNzIjoiaHR0cHM6Ly9zYW5kYm94LWxvZ2luLmlucG9zdC5wbC9hdXRoL3JlYWxtcy9leHRlcm5hbCIsInN1YiI6ImY6N2ZiZjQxYmEtYTEzZC00MGQzLTk1ZjYtOThhMmIxYmFlNjdiOjR2UlJaSDZHNW1LUWdTa2FQXy0yWFVKd19pT0hvTUIwMDF1aGE4SE5aVzAiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJzaGlweCIsInNlc3Npb25fc3RhdGUiOiI0NzI1NjUwMi04NjIzLTQ2YmUtOTRmOC02NTA0YzZmNjk2MTMiLCJzY29wZSI6Im9wZW5pZCBhcGk6YXBpcG9pbnRzIGFwaTpzaGlweCIsInNpZCI6IjQ3MjU2NTAyLTg2MjMtNDZiZS05NGY4LTY1MDRjNmY2OTYxMyIsImFsbG93ZWRfcmVmZXJyZXJzIjoiIiwidXVpZCI6IjMxNzAwYmU3LTA2ZTAtNGVkZC05NTA1LTAzZjJhZjQ3M2QwMiIsImVtYWlsIjoia29udGFrdEBwaWNhYmVsYS5wbCJ9.gi0k1iTptAMC0iAILF9hfU5QsM3xClD59XcAs4Dax7FfGmoQTBlnsirBRO6bdVsAEaAN7eXB6kVzIc2om5bFocK8Xtk_z5ih9Piu-PmLKFp9FABmO1KUbq6ZprKBgZvHGEv01IIAgUvqKWfs_PldlCwwj9pBSjgp5IlGHiO0_xRX0kQiAd6RfIWLYuUi_zjTVltv1jS0eJ_eVmA2TOzxb2UF7mZrEpsIcoWbi_yba9g2GgJ46VxrRDI998TgBENPpMLFOECoG_-y60PF2nSU9Bl92qu0e6knxs_DxNYk_dScM0KKT842MorbniHGXcN-V8AfZzgvV1pxDLeqpb1IGA";
$inpost_sandbox_enabled = get_setting('inpost_sandbox_enabled', $pdo); // Sprawdź tryb pracy z bazy
$inpost_apiUrlBase = $inpost_sandbox_enabled ? "https://sandbox-api-shipx-pl.easypack24.net/v1" : "https://api-shipx-pl.easypack24.net/v1";
$inpost_labelUrlBase = $inpost_apiUrlBase . "/shipments/"; // Bazowy URL do etykiet

// Sprawdź, czy przekazano ID przesyłki
if (!isset($_GET['shipment_id']) || !ctype_digit((string)$_GET['shipment_id'])) { // Użyj ctype_digit dla pewności
    log_message("fetch_label.php: Błąd - Brak lub nieprawidłowe ID przesyłki w GET.");
    http_response_code(400);
    die("Błąd: Brak lub nieprawidłowe ID przesyłki.");
}

$shipmentId = $_GET['shipment_id'];
$labelUrl = $inpost_labelUrlBase . $shipmentId . '/label?format=pdf'; // Skonstruuj pełny URL do API InPost

log_message("fetch_label.php: Żądanie pobrania etykiety dla ID: {$shipmentId} z URL: {$labelUrl}");

// === Pobierz etykietę z API InPost ===
$ch = curl_init($labelUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true, // Zwróć odpowiedź jako string
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $inpost_token // Uwierzytelnienie tokenem!
    ],
    CURLOPT_SSL_VERIFYPEER => false, // Ignorowanie weryfikacji SSL (zmień na true na produkcji)
    CURLOPT_SSL_VERIFYHOST => false, // Ignorowanie weryfikacji hosta (zmień na 2 na produkcji)
    CURLOPT_FOLLOWLOCATION => true, // Podążaj za przekierowaniami (ważne, InPost może ich używać)
    CURLOPT_FAILONERROR => false, // Nie traktuj kodów HTTP 4xx/5xx jako błędu cURL, chcemy odczytać odpowiedź
    CURLOPT_TIMEOUT => 30, // Limit czasu
]);

$pdfContent = curl_exec($ch); // Wykonaj żądanie
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE); // Pobierz kod statusu HTTP
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE); // Pobierz typ zawartości odpowiedzi
$curlError = curl_error($ch); // Sprawdź, czy wystąpił błąd cURL
curl_close($ch);

// === Sprawdź odpowiedź i zwróć PDF lub błąd ===
if ($curlError) {
    log_message("fetch_label.php: Błąd cURL podczas pobierania etykiety dla ID {$shipmentId}: " . $curlError);
    http_response_code(500); // Błąd serwera (problem z połączeniem)
    die("Wystąpił błąd serwera podczas próby pobrania etykiety. Skontaktuj się z administratorem.");
} elseif ($httpCode == 200 && $pdfContent !== false && strpos($contentType, 'application/pdf') !== false) {
    // Sukces - otrzymano PDF
    log_message("fetch_label.php: Pomyślnie pobrano etykietę PDF dla ID: {$shipmentId}");

    // Ustaw nagłówki HTTP, aby przeglądarka zainicjowała pobieranie pliku PDF
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="etykieta_inpost_' . $shipmentId . '.pdf"'); // Sugerowana nazwa pliku
    header('Content-Length: ' . strlen($pdfContent)); // Długość zawartości
    header('Cache-Control: private'); // Zapobiegaj cachowaniu przez pośredników

    // Wyślij zawartość pliku PDF do przeglądarki
    echo $pdfContent;
    exit;
} else {
    // Wystąpił błąd po stronie InPost lub inny problem
    log_message("fetch_label.php: Błąd podczas pobierania etykiety dla ID {$shipmentId}. HTTP: {$httpCode}. Content-Type: {$contentType}. Odpowiedź: " . substr($pdfContent, 0, 500)); // Loguj fragment odpowiedzi
    http_response_code($httpCode == 401 ? 401 : ($httpCode >= 400 ? $httpCode : 500)); // Zwróć kod błędu InPost lub 500

    // Wyświetl bardziej szczegółowy komunikat błędu użytkownikowi (ale bez wrażliwych danych)
    echo "<!DOCTYPE html><html lang='pl'><head><meta charset='UTF-8'><title>Błąd Pobierania Etykiety</title></head><body>";
    echo "<h1>Błąd podczas pobierania etykiety</h1>";
    echo "<p>Nie udało się pobrać etykiety dla przesyłki o ID: " . htmlspecialchars($shipmentId) . ".</p>";
    if ($httpCode == 401) {
        echo "<p><strong>Przyczyna:</strong> Błąd autoryzacji (nieprawidłowy lub wygasły token API InPost).</p>";
    } elseif ($httpCode == 404) {
        echo "<p><strong>Przyczyna:</strong> Nie znaleziono przesyłki o podanym ID.</p>";
    } else {
        echo "<p><strong>Kod błędu HTTP:</strong> " . $httpCode . "</p>";
    }
    echo "<p>Proszę spróbować ponownie później lub skontaktować się z administratorem.</p>";
    // Wyświetl odpowiedź InPost (jeśli jest tekstowa lub JSON) dla debugowania
    if (!empty($pdfContent) && ($httpCode != 200 || strpos($contentType, 'application/pdf') === false)) {
       echo "<h2>Odpowiedź serwera InPost:</h2><pre style='background:#eee; padding:10px; border:1px solid #ccc; border-radius:4px; word-wrap:break-word; white-space:pre-wrap;'>" . htmlspecialchars($pdfContent) . "</pre>";
    }
    echo "</body></html>";
    exit;
}
?>