<?php
// /zamowienie/admin/settings.php

require_once 'includes/auth_check.php';
require_once '../includes/db.php';
require_once '../includes/functions.php'; // Potrzebne get_all_settings, get_current_setting_value, is_sandbox_enabled

$page_title = "Ustawienia Systemu";
include 'includes/header.php';

$success_message = $_SESSION['success_message'] ?? null;
$error_message = $_SESSION['error_message'] ?? null;
unset($_SESSION['success_message'], $_SESSION['error_message']);

// --- Logika obsługi zapisywania ustawień ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_settings') {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
        $error_message = "Błąd CSRF Token. Odśwież stronę i spróbuj ponownie.";
    } else {
        // Lista *wszystkich* kluczy, które mogą być przesłane z formularza
        $settings_keys_from_form = [
            'sandbox_p24_pos_id', 'sandbox_p24_crc_key', 'sandbox_p24_api_key', 'p24_sandbox_enabled',
            'production_p24_pos_id', 'production_p24_crc_key', 'production_p24_api_key',
            'sandbox_inpost_org_id', 'sandbox_inpost_token', 'inpost_sandbox_enabled',
            'production_inpost_org_id', 'production_inpost_token',
            'service_receiver_name', 'service_receiver_email', 'service_receiver_phone', 'service_receiver_locker',
            'sender_name_override',
            'email_from_address', 'email_from_name'
        ];

        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
            // Używamy INSERT ... ON DUPLICATE KEY UPDATE, aby obsłużyć zarówno nowe, jak i istniejące klucze

            foreach ($settings_keys_from_form as $key) {
                // Pobierz wartość z POST
                if (str_ends_with($key, '_enabled')) { // Checkboxy trybu sandbox
                    $value = isset($_POST[$key]) ? 'true' : 'false';
                } else {
                    $value = isset($_POST[$key]) ? trim($_POST[$key]) : ''; // Trim usuwa białe znaki
                }

                // Walidacja (można dodać bardziej szczegółową)
                // Na razie tylko zapisujemy
                $stmt->execute([$key, $value]);
            }

            $pdo->commit();
            $_SESSION['success_message'] = "Ustawienia zostały pomyślnie zaktualizowane.";
            header("Location: settings.php");
            exit;

        } catch (\PDOException $e) {
            $pdo->rollBack();
            error_log("DB Error updating settings: " + $e->getMessage());
            $error_message = "Wystąpił błąd serwera podczas zapisywania ustawień.";
        }
    }
}

// Wygeneruj/pobierz token CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// --- Pobieranie wszystkich aktualnych ustawień z bazy ---
$current_settings = get_all_settings($pdo); // Użyj nowej funkcji z functions.php

?>

<h2><?php echo $page_title; ?></h2>

<?php if ($success_message): ?><div class="success-message"><?php echo htmlspecialchars($success_message); ?></div><?php endif; ?>
<?php if ($error_message): ?><div class="error-message"><?php echo htmlspecialchars($error_message); ?></div><?php endif; ?>

<p>Wprowadź klucze API dla środowisk Sandbox (testowego) i Produkcyjnego. Przełączniki "Tryb Sandbox" decydują, które klucze są aktualnie używane przez aplikację.</p>

<form action="settings.php" method="POST" class="settings-form">
    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
    <input type="hidden" name="action" value="save_settings">

    <fieldset>
        <legend>Ustawienia Przelewy24</legend>

        <div class="setting-group">
            <h3>Środowisko Sandbox (Testowe)</h3>
            <label for="sandbox_p24_pos_id">Sandbox POS ID</label>
            <input type="text" id="sandbox_p24_pos_id" name="sandbox_p24_pos_id" value="<?php echo get_current_setting_value('sandbox_p24_pos_id', $current_settings); ?>">

            <label for="sandbox_p24_crc_key">Sandbox Klucz CRC</label>
            <input type="text" id="sandbox_p24_crc_key" name="sandbox_p24_crc_key" value="<?php echo get_current_setting_value('sandbox_p24_crc_key', $current_settings); ?>">

            <label for="sandbox_p24_api_key">Sandbox Klucz API (do raportów)</label>
            <input type="text" id="sandbox_p24_api_key" name="sandbox_p24_api_key" value="<?php echo get_current_setting_value('sandbox_p24_api_key', $current_settings); ?>" class="monospace">

             <label class="checkbox-label" for="p24_sandbox_enabled">
                <input type="checkbox" id="p24_sandbox_enabled" name="p24_sandbox_enabled" value="true" <?php echo is_sandbox_enabled('p24_sandbox_enabled', $current_settings) ? 'checked' : ''; ?>>
                <strong>Aktywny Tryb Sandbox dla Przelewy24</strong>
            </label>
             <small>Zaznacz, aby używać powyższych kluczy testowych.</small>
        </div>

         <hr class="separator">

        <div class="setting-group">
             <h3>Środowisko Produkcyjne</h3>
            <label for="production_p24_pos_id">Produkcyjny POS ID</label>
            <input type="text" id="production_p24_pos_id" name="production_p24_pos_id" value="<?php echo get_current_setting_value('production_p24_pos_id', $current_settings); ?>">

            <label for="production_p24_crc_key">Produkcyjny Klucz CRC</label>
            <input type="text" id="production_p24_crc_key" name="production_p24_crc_key" value="<?php echo get_current_setting_value('production_p24_crc_key', $current_settings); ?>">

            <label for="production_p24_api_key">Produkcyjny Klucz API (do raportów)</label>
            <input type="text" id="production_p24_api_key" name="production_p24_api_key" value="<?php echo get_current_setting_value('production_p24_api_key', $current_settings); ?>" class="monospace">
        </div>
    </fieldset>

    <fieldset>
        <legend>Ustawienia InPost API (ShipX)</legend>
         <div class="setting-group">
            <h3>Środowisko Sandbox (Testowe)</h3>
            <label for="sandbox_inpost_org_id">Sandbox ID Organizacji</label>
            <input type="text" id="sandbox_inpost_org_id" name="sandbox_inpost_org_id" value="<?php echo get_current_setting_value('sandbox_inpost_org_id', $current_settings); ?>">

            <label for="sandbox_inpost_token">Sandbox Token API (Bearer)</label>
            <textarea id="sandbox_inpost_token" name="sandbox_inpost_token" class="monospace token-area"><?php echo get_current_setting_value('sandbox_inpost_token', $current_settings); ?></textarea>

             <label class="checkbox-label" for="inpost_sandbox_enabled">
                <input type="checkbox" id="inpost_sandbox_enabled" name="inpost_sandbox_enabled" value="true" <?php echo is_sandbox_enabled('inpost_sandbox_enabled', $current_settings) ? 'checked' : ''; ?>>
                <strong>Aktywny Tryb Sandbox dla InPost</strong>
            </label>
             <small>Zaznacz, aby używać powyższych kluczy testowych InPost.</small>
         </div>

         <hr class="separator">

         <div class="setting-group">
             <h3>Środowisko Produkcyjne</h3>
            <label for="production_inpost_org_id">Produkcyjne ID Organizacji</label>
            <input type="text" id="production_inpost_org_id" name="production_inpost_org_id" value="<?php echo get_current_setting_value('production_inpost_org_id', $current_settings); ?>">

            <label for="production_inpost_token">Produkcyjny Token API (Bearer)</label>
            <textarea id="production_inpost_token" name="production_inpost_token" class="monospace token-area"><?php echo get_current_setting_value('production_inpost_token', $current_settings); ?></textarea>
         </div>
    </fieldset>

    <fieldset>
        <legend>Dane Odbiorcy (Serwisu Naprawczego)</legend>
        <div class="setting-group">
            <label for="service_receiver_name">Nazwa odbiorcy (na etykiecie)</label>
            <input type="text" id="service_receiver_name" name="service_receiver_name" value="<?php echo get_current_setting_value('service_receiver_name', $current_settings); ?>" required>

            <label for="service_receiver_email">E-mail odbiorcy</label>
            <input type="email" id="service_receiver_email" name="service_receiver_email" value="<?php echo get_current_setting_value('service_receiver_email', $current_settings); ?>" required>

            <label for="service_receiver_phone">Telefon odbiorcy</label>
            <input type="tel" id="service_receiver_phone" name="service_receiver_phone" value="<?php echo get_current_setting_value('service_receiver_phone', $current_settings); ?>" required>

            <label for="service_receiver_locker">Docelowy Paczkomat odbiorcy (ID)</label>
            <input type="text" id="service_receiver_locker" name="service_receiver_locker" value="<?php echo get_current_setting_value('service_receiver_locker', $current_settings); ?>" required>
        </div>
    </fieldset>

     <fieldset>
        <legend>Ustawienia Nadawcy i E-mail</legend>
        <div class="setting-group">
            <label for="sender_name_override">Nadpisz nazwę nadawcy na etykiecie InPost</label>
            <input type="text" id="sender_name_override" name="sender_name_override" value="<?php echo get_current_setting_value('sender_name_override', $current_settings); ?>">
            <small>Zostaw puste, aby użyć danych klienta. Wpisz np. "BUTOLOG".</small>

            <label for="email_from_address">Adres e-mail "Od" (w powiadomieniach)</label>
            <input type="email" id="email_from_address" name="email_from_address" value="<?php echo get_current_setting_value('email_from_address', $current_settings); ?>" required>

            <label for="email_from_name">Nazwa nadawcy "Od" (w powiadomieniach)</label>
            <input type="text" id="email_from_name" name="email_from_name" value="<?php echo get_current_setting_value('email_from_name', $current_settings); ?>" required>
        </div>
     </fieldset>

    <button type="submit" class="button">Zapisz Ustawienia</button>
</form>

<?php
include 'includes/footer.php';
?>