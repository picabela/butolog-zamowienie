<?php
// /zamowienie/p24_status.php

// Ignoruj przerwanie połączenia przez klienta (P24), kontynuuj działanie skryptu
ignore_user_abort(true);
// Ustaw odpowiednio długi czas wykonywania skryptu
set_time_limit(120); // 2 minuty

require_once 'includes/db.php'; // Połączenie z bazą i funkcja get_setting()
require_once 'includes/functions.php'; // Funkcje pomocnicze

// --- Pobranie *aktywnej* konfiguracji z bazy danych ---
$p24_posId = get_active_setting('p24_pos_id', $pdo);
$p24_crcKey = get_active_setting('p24_crc_key', $pdo);
$p24_apiKey = get_active_setting('p24_api_key', $pdo);
$p24_sandbox_enabled = get_setting('p24_sandbox_enabled', $pdo);
$p24_apiUrlBase = $p24_sandbox_enabled ? "https://sandbox.przelewy24.pl/api/v1" : "https://secure.przelewy24.pl/api/v1";
$p24_verifyUrl = $p24_apiUrlBase . '/transaction/verify';

$inpost_org_id = get_active_setting('inpost_org_id', $pdo);
$inpost_token = get_active_setting('inpost_token', $pdo);
$inpost_sandbox_enabled = get_setting('inpost_sandbox_enabled', $pdo);
$inpost_apiUrlBase = $inpost_sandbox_enabled ? "https://sandbox-api-shipx-pl.easypack24.net/v1" : "https://api-shipx-pl.easypack24.net/v1";
$inpost_createShipmentUrl = $inpost_apiUrlBase . "/organizations/{$inpost_org_id}/shipments";
$inpost_getShipmentBaseUrl = $inpost_apiUrlBase . "/shipments/";

$receiver_name = get_setting('service_receiver_name', $pdo);
$receiver_email = get_setting('service_receiver_email', $pdo);
$receiver_phone = get_setting('service_receiver_phone', $pdo);
$receiver_locker = get_setting('service_receiver_locker', $pdo);
$sender_name_override = get_setting('sender_name_override', $pdo);
$email_from_address = get_setting('email_from_address', $pdo);
$email_from_name = get_setting('email_from_name', $pdo);

// Sprawdzenie kluczowych ustawień
$p24_mode_text = $p24_sandbox_enabled ? 'sandbox' : 'production';
$inpost_mode_text = $inpost_sandbox_enabled ? 'sandbox' : 'production';
if (!$p24_posId || !$p24_crcKey || !$p24_apiKey || !$inpost_org_id || !$inpost_token || !$receiver_locker || !$email_from_address || !$email_from_name) {
    log_message("KRYTYCZNY BŁĄD w p24_status.php: Brak kluczowych aktywnych ustawień (P24: {$p24_mode_text}, InPost: {$inpost_mode_text}). Sprawdź tabelę settings.");
    http_response_code(500); exit("Internal Server Configuration Error");
}

// === KROK 1: Odbierz powiadomienie P24 ===
log_message("--- Nowe powiadomienie P24 [p24_status.php] ---");
$jsonInput = file_get_contents('php://input');
log_message("Odebrano dane P24: " . $jsonInput);
$p24WebhookData = json_decode($jsonInput, true);
if (!$p24WebhookData || !isset($p24WebhookData['orderId']) || !isset($p24WebhookData['sessionId']) || !isset($p24WebhookData['amount']) || !isset($p24WebhookData['currency'])) {
    log_message("Błąd P24 Webhook: Nieprawidłowe dane JSON lub brak kluczowych pól.");
    http_response_code(400); exit("Invalid Webhook Data");
}
$session_id = $p24WebhookData['sessionId'];

// === KROK 1.5: Sprawdź zamówienie w bazie ===
try {
    $stmt_check = $pdo->prepare("SELECT id, payment_status, repair_status, sender_name, sender_email, sender_phone, return_locker_id, inpost_shipment_id, inpost_tracking_number FROM orders WHERE session_id = ?");
    $stmt_check->execute([$session_id]);
    $order = $stmt_check->fetch();
    if (!$order) {
        log_message("Błąd: Nie znaleziono zamówienia w bazie danych dla sessionId: " . $session_id);
        http_response_code(404); exit("Order Not Found");
    }
    // Jeśli zamówienie już zostało opłacone i etykieta wygenerowana, nie rób nic więcej
    if ($order['payment_status'] == 'paid' && $order['repair_status'] == 'label_generated') {
         log_message("Informacja: Otrzymano powtórne powiadomienie dla już przetworzonego zamówienia sessionId: " . $session_id);
         http_response_code(200); exit("OK - Already Processed");
    }
} catch (\PDOException $e) {
    error_log("DB Error checking order (sessionId: {$session_id}): " . $e->getMessage());
    http_response_code(500); exit("Internal Server Error - DB Check");
}

// === KROK 2: Weryfikacja P24 ===
log_message("Rozpoczynanie weryfikacji P24 dla sessionId: " . $session_id . ", P24 OrderID: " . $p24WebhookData['orderId']);
$verifySignData = [ "sessionId" => $session_id, "orderId" => (int)$p24WebhookData['orderId'], "amount" => (int)$p24WebhookData['amount'], "currency" => $p24WebhookData['currency'], "crc" => $p24_crcKey ];
$verifySign = hash('sha384', json_encode($verifySignData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
$verifyPayload = [ "merchantId" => (int)$p24_posId, "posId" => (int)$p24_posId, "sessionId" => $session_id, "amount" => (int)$p24WebhookData['amount'], "currency" => $p24WebhookData['currency'], "orderId" => (int)$p24WebhookData['orderId'], "sign" => $verifySign ];

log_message("Dane do podpisu weryfikacji: " . json_encode($verifySignData));
log_message("Wygenerowany podpis weryfikacji: " . $verifySign);
log_message("Pełny payload weryfikacji wysyłany do P24: " . json_encode($verifyPayload));
log_message("Klucze używane do autoryzacji weryfikacji: User=[" . $p24_posId . "] Key=[" . substr($p24_apiKey, 0, 5) . "...]");

$p24VerifyResult = call_p24_api($p24_verifyUrl, $p24_posId, $p24_apiKey, $verifyPayload, 'PUT');
log_message("Odpowiedź weryfikacji P24 (HTTP {$p24VerifyResult['http_code']}): " . $p24VerifyResult['response']);

// === KROK 3: Płatność zweryfikowana - InPost i Email ===
if ($p24VerifyResult['http_code'] == 200 && isset($p24VerifyResult['data']['data']['status']) && $p24VerifyResult['data']['data']['status'] == 'success') {
    log_message("Weryfikacja P24 Pomyślna dla sessionId: {$session_id}");

    // Oznacz zamówienie jako opłacone (tylko jeśli było 'pending')
    $updatedRows = 0; // Zmienna do śledzenia, czy status został zaktualizowany
    if ($order['payment_status'] == 'pending') {
        try {
            $stmt_update_paid = $pdo->prepare("UPDATE orders SET payment_status = 'paid', p24_order_id = ?, updated_at = NOW() WHERE session_id = ? AND payment_status = 'pending'");
            $updatedRows = $stmt_update_paid->execute([$p24WebhookData['orderId'], $session_id]) ? $stmt_update_paid->rowCount() : 0;
            if ($updatedRows > 0) {
                 log_message("Zaktualizowano status zamówienia {$session_id} na 'paid'.");
                 $order['payment_status'] = 'paid'; // Zaktualizuj status w zmiennej $order
            } else {
                 log_message("OSTRZEŻENIE: Weryfikacja P24 pomyślna, ale nie udało się zaktualizować statusu 'pending' na 'paid' w bazie dla sessionId: {$session_id}. Sprawdź zamówienie ręcznie!");
            }
        } catch (\PDOException $e) {
            error_log("DB Error updating order to paid for {$session_id}: " . $e->getMessage());
            // Kontynuujemy, ale z ryzykiem, że status nie został zapisany
        }
    } else {
        log_message("Informacja: Zamówienie {$session_id} miało już status {$order['payment_status']}, nie aktualizowano na 'paid'.");
    }


    // Sprawdź, czy etykieta nie została już wygenerowana (pobieramy ID z $order)
    $existing_shipment_id = $order['inpost_shipment_id'];

    if ($existing_shipment_id && $order['repair_status'] == 'label_generated') {
        log_message("Informacja: Etykieta InPost dla sessionId {$session_id} została już wcześniej wygenerowana (ID: {$existing_shipment_id}). Pomijanie tworzenia nowej.");
        // Można rozważyć ponowne wysłanie e-maila, jeśli np. poprzednie się nie powiodło,
        // ale obecna logika zakłada, że jeśli status jest 'label_generated', to e-mail został wysłany.

    } else {
        // --- Generowanie Etykiety InPost ---
        log_message("Rozpoczynanie generowania etykiety InPost dla sessionId: {$session_id}");

        // === SPRAWDZENIE ODCZYTU DANYCH KLIENTA (z bazy, bo plik sesji już nie istnieje) ===
        // Dane klienta są już w zmiennej $order pobranej wcześniej
        if (empty($order['sender_email'])) { // Sprawdźmy kluczowe pole
             log_message("BŁĄD KRYTYCZNY: Brak danych klienta (np. e-mail) w zamówieniu {$session_id} pobranym z bazy.");
             // Oznacz błąd w zamówieniu
             try { $pdo->prepare("UPDATE orders SET repair_status = 'cancelled' WHERE session_id = ?")->execute([$session_id]); } catch (\PDOException $e) { /* log */ }
             http_response_code(200); // Odpowiedz P24 OK
             exit("OK - Missing Customer Data in DB");
        }
        log_message("Pomyślnie pobrano dane klienta z bazy dla sessionId: {$session_id}");
        // =======================================================

        // 3.1. Przygotuj payload dla API InPost
        $sender_name_inpost = !empty($sender_name_override) ? $sender_name_override : $order['sender_name'];
        $sender_company_name_inpost = $sender_name_inpost;

        $inpostPayload = [
            'receiver' => ['name' => $receiver_name, 'email' => $receiver_email, 'phone' => $receiver_phone],
            'sender' => [
                'name' => $sender_name_inpost,
                'company_name' => $sender_company_name_inpost,
                'email' => $order['sender_email'], // Użyj danych z $order
                'phone' => $order['sender_phone']  // Użyj danych z $order
            ],
            'parcels' => [['template' => 'medium']],
            'service' => 'inpost_locker_standard',
            'reference' => $session_id,
            'comments' => 'Naprawa obuwia (Zam: ' . $session_id . ')',
            'sending_method' => 'any_point',
            'custom_attributes' => ['target_point' => $receiver_locker, 'sending_method' => 'any_point']
        ];
        log_message("Wysyłanie żądania utworzenia przesyłki InPost: " . json_encode($inpostPayload));

        // 3.2. Wywołaj API InPost
        $inpostCreateResult = call_inpost_api_post($inpost_createShipmentUrl, $inpost_token, $inpostPayload);
        log_message("Odpowiedź InPost (tworzenie) (HTTP {$inpostCreateResult['http_code']}): " . $inpostCreateResult['response']);
        $inpostCreateResponse = $inpostCreateResult['data'];

        // 3.3. Przetwórz odpowiedź InPost i wyślij e-mail
        if ($inpostCreateResult['http_code'] == 201 && isset($inpostCreateResponse['id'])) {
            $shipmentId = $inpostCreateResponse['id'];
            $trackingNumber = $inpostCreateResponse['tracking_number'] ?? null;
            $targetLocker = $inpostCreateResponse['custom_attributes']['target_point'] ?? ($inpostCreateResponse['target_point'] ?? $receiver_locker);

            log_message("Sukces InPost! Utworzono przesyłkę. ID: {$shipmentId}, Tracking (początkowy): {$trackingNumber}, Paczkomat: {$targetLocker}");

            if (empty($trackingNumber)) {
                log_message("Numer śledzenia pusty/null. Czekam 5 sekund i pobieram ponownie...");
                sleep(5);
                $inpostGetShipmentUrl = $inpost_getShipmentBaseUrl . $shipmentId;
                $inpostGetResult = call_inpost_api_get($inpostGetShipmentUrl, $inpost_token);
                log_message("Odpowiedź InPost (GET /shipments/{$shipmentId}) (HTTP {$inpostGetResult['http_code']}): " . $inpostGetResult['response']);

                if ($inpostGetResult['http_code'] == 200 && isset($inpostGetResult['data']['tracking_number']) && !empty($inpostGetResult['data']['tracking_number'])) {
                    $trackingNumber = $inpostGetResult['data']['tracking_number'];
                    log_message("Pobrano zaktualizowany numer śledzenia: {$trackingNumber}");
                } else {
                    log_message("Nie udało się pobrać zaktualizowanych danych przesyłki lub numer śledzenia nadal nie jest dostępny.");
                    $trackingNumber = 'Oczekuje na nadanie';
                }
            }

            // Zaktualizuj zamówienie w bazie danych o dane InPost
            $trackingNumberForDb = ($trackingNumber == 'Oczekuje na nadanie' || empty($trackingNumber)) ? null : $trackingNumber; // Zapisz null jeśli nie ma numeru
            try {
                $stmt_update_inpost = $pdo->prepare("UPDATE orders SET inpost_shipment_id = ?, inpost_tracking_number = ?, repair_status = 'label_generated', updated_at = NOW() WHERE session_id = ?");
                $stmt_update_inpost->execute([$shipmentId, $trackingNumberForDb, $session_id]);
                 log_message("Zaktualizowano zamówienie {$session_id} o dane InPost.");
            } catch (\PDOException $e) {
                error_log("DB Error updating order with InPost data for {$session_id}: " . $e->getMessage());
            }

            // Wyślij e-mail do klienta
            $labelDownloadPageLink = "https://butolog.pl/zamowienie/download_page.php?shipment_id=" . $shipmentId;
            $customerEmail = $order['sender_email'];
            $customerName = $order['sender_name'];
            $returnLockerId = $order['return_locker_id'];
            $amountPaid = number_format($p24WebhookData['amount'] / 100, 2, ',', '');
            $currency = $p24WebhookData['currency'];

            $subject = "Potwierdzenie opłaty i etykieta nadawcza {$email_from_name} (Zam: {$sessionId})";
            $message = "Witaj {$customerName},\n\n"
                     . "Dziękujemy za opłacenie usługi naprawy obuwia (Zamówienie: {$sessionId}) w {$email_from_name}.\n\n"
                     . "Status płatności: OPŁACONE\n"
                     . "Kwota: {$amountPaid} {$currency}\n\n"
                     . "--- ETYKIETA NADAWCZA INPOST ---\n\n"
                     . "Wygenerowaliśmy dla Ciebie etykietę, abyś mógł wysłać do nas swoje buty.\n\n"
                     . "**Strona do pobrania etykiety (PDF):**\n"
                     . $labelDownloadPageLink . "\n\n"
                     . "**Numer przesyłki (śledzenia) do nas:** {$trackingNumber}\n\n" // Użyj $trackingNumber
                     . "Prosimy o nadanie paczki w dowolnym paczomacie lub PaczkoPunkcie. Została ona zaadresowana do naszego paczkomatu: {$targetLocker}.\n\n"
                     . "--- DANE ZWROTNE ---\n"
                     . "Po naprawie odeślemy buty do wskazanego przez Ciebie paczkomatu: {$returnLockerId}.\n\n"
                     . "Pozdrawiamy,\n"
                     . "Zespół {$email_from_name}";

            $headers = "From: {$email_from_name} <{$email_from_address}>\r\n"
                     . "Reply-To: {$email_from_address}\r\n"
                     . "Content-Type: text/plain; charset=UTF-8\r\n"
                     . "X-Mailer: PHP/" . phpversion();

            if (mail($customerEmail, $subject, $message, $headers)) {
                log_message("Pomyślnie wysłano e-mail dla sessionId: {$session_id} na adres: " . $customerEmail);
            } else {
                log_message("BŁĄD: mail() nie powiodło się dla sessionId: {$session_id}. Sprawdź konfigurację serwera pocztowego.");
                error_log("PHP Mail Error: Failed to send email to {$customerEmail} for session {$session_id}");
            }

        } else {
            // Błąd podczas tworzenia przesyłki InPost
            $errorResponse = $inpostCreateResult['response'] ?? 'Brak odpowiedzi InPost';
            log_message("BŁĄD KRYTYCZNY INPOST dla sessionId: {$session_id}. Nie udało się wygenerować etykiety. Odpowiedź (HTTP {$inpostCreateResult['http_code']}): " . $errorResponse);
            try {
                $stmt_update_error = $pdo->prepare("UPDATE orders SET repair_status = 'cancelled', payment_status = 'paid', updated_at = NOW() WHERE session_id = ?");
                $stmt_update_error->execute([$session_id]);
                 log_message("Zaktualizowano status zamówienia {$session_id} na 'cancelled' po błędzie InPost.");
            } catch (\PDOException $e) {
                error_log("DB Error updating order status to cancelled after InPost error for {$session_id}: " . $e->getMessage());
            }
            // TODO: Wyślij powiadomienie do admina o błędzie generowania etykiety!
        }
    } // Koniec bloku 'if (!$existing_shipment_id)'

} else {
    // Weryfikacja P24 nie powiodła się
    $errorResponseP24 = $p24VerifyResult['response'] ?? 'Brak odpowiedzi P24';
    log_message("Błąd weryfikacji P24 dla sessionId: {$session_id}. Odpowiedź P24 (HTTP {$p24VerifyResult['http_code']}): " . $errorResponseP24);
    try {
         $stmt_update_failed = $pdo->prepare("UPDATE orders SET payment_status = 'failed', updated_at = NOW() WHERE session_id = ? AND payment_status = 'pending'");
         $updatedRowsFailed = $stmt_update_failed->execute([$session_id]);
          if ($updatedRowsFailed > 0) {
              log_message("Zaktualizowano status zamówienia {$session_id} na 'failed'.");
          }
    } catch (\PDOException $e) {
         error_log("DB Error updating order status to failed for {$session_id}: " . $e->getMessage());
    }
}

// === KROK 4: Zawsze odpowiedz P24 kodem 200 OK ===
http_response_code(200);
echo "OK";
exit;

?>