<?php
// /zamowienie/p24_process.php
// === DODAJ TEN BLOK ===
require_once 'includes/functions.php'; // Potrzebne do log_message
$server_ip = @file_get_contents('https://icanhazip.com');
if ($server_ip) {
    log_message("Adres IP serwera wg icanhazip.com: " . trim($server_ip));
} else {
    log_message("Nie udało się pobrać adresu IP serwera z icanhazip.com.");
}
// ======================

// Wczytaj konfigurację, połączenie z bazą i funkcje pomocnicze
require_once 'includes/db.php';
require_once 'includes/functions.php'; // Potrzebne generate_uuid() i P24 API call

// Upewnij się, że sesja jest aktywna (potrzebna do komunikatów o błędach)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Sprawdź, czy żądanie jest metodą POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    // Jeśli ktoś wszedł tu bezpośrednio przez GET, przekieruj
    header("Location: index.php");
    exit;
}

// 1. Walidacja i bezpieczne pobranie danych z formularza POST
$form_id = filter_input(INPUT_POST, 'form_id', FILTER_VALIDATE_INT);
$amount_from_form = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT); // Cena z formularza (do weryfikacji)
$service_name = filter_input(INPUT_POST, 'service_name', FILTER_DEFAULT); // Zamiast FILTER_SANITIZE_STRING
$sender_name = filter_input(INPUT_POST, 'sender_name', FILTER_DEFAULT); // Zamiast FILTER_SANITIZE_STRING
$sender_email = filter_input(INPUT_POST, 'sender_email', FILTER_VALIDATE_EMAIL);
$sender_phone = filter_input(INPUT_POST, 'sender_phone', FILTER_DEFAULT); // Zamiast FILTER_SANITIZE_STRING
// Podstawowa walidacja numeru telefonu (czy zawiera cyfry, opcjonalnie +, -, spacje)
$sender_phone = preg_replace('/[^+0-9]/', '', $sender_phone); // Usuń niechciane znaki
$return_locker_id = filter_input(INPUT_POST, 'return_locker_id', FILTER_DEFAULT); // Zamiast FILTER_SANITIZE_STRING
// Prosta walidacja ID paczkomatu (np. 3 litery, 3 cyfry, opcjonalnie M)
$return_locker_id = strtoupper(preg_replace('/[^A-Z0-9]/i', '', $return_locker_id));

// Sprawdź, czy wszystkie wymagane pola są poprawne
if (!$form_id || $amount_from_form === false || !$service_name || !$sender_name || !$sender_email || empty($sender_phone) || empty($return_locker_id)) {
    $_SESSION['error_message'] = "Nieprawidłowe lub brakujące dane w formularzu. Proszę wypełnić wszystkie pola poprawnie.";
    // Potrzebujemy UUID formularza, żeby wrócić
    try {
        $stmt_uuid = $pdo->prepare("SELECT uuid FROM forms WHERE id = ?");
        $stmt_uuid->execute([$form_id ?? 0]); // Użyj 0 jeśli form_id jest niepoprawne
        $form_uuid_redirect = $stmt_uuid->fetchColumn();
        if ($form_uuid_redirect) {
            header("Location: form.php?uuid=" . $form_uuid_redirect);
        } else {
            header("Location: index.php"); // Fallback, jeśli nawet form_id było złe
        }
    } catch (\PDOException $e) {
         error_log("DB Error fetching form UUID for redirect: " . $e->getMessage());
         header("Location: index.php"); // Fallback
    }
    exit;
}

// 2. Weryfikacja ceny z bazą danych (bardzo ważne!)
try {
    $stmt_form_check = $pdo->prepare("SELECT price, uuid FROM forms WHERE id = ? AND is_active = TRUE");
    $stmt_form_check->execute([$form_id]);
    $form_data = $stmt_form_check->fetch();

    if (!$form_data) {
        throw new Exception("Formularz nie istnieje lub jest nieaktywny.");
    }

    $db_price = (float)$form_data['price'];
    $form_uuid = $form_data['uuid']; // Pobierz UUID do ewentualnego powrotu z błędem

    // Porównaj cenę z formularza z ceną w bazie (tolerancja dla błędów float)
    if (abs($db_price - $amount_from_form) > 0.01) {
        throw new Exception("Niezgodność ceny przesłanej z formularza z ceną w bazie danych.");
    }
    $amount_grosze = (int) round($db_price * 100); // Używaj ceny z bazy! Użyj round dla pewności

} catch (\PDOException | \Exception $e) {
    error_log("Błąd weryfikacji formularza/ceny (form_id: {$form_id}): " . $e->getMessage());
    $_SESSION['error_message'] = "Wystąpił błąd podczas weryfikacji danych formularza. Spróbuj ponownie.";
    // Jeśli mamy UUID, wróć do formularza
    if (isset($form_uuid)) {
        header("Location: form.php?uuid=" . $form_uuid);
    } else {
        header("Location: index.php");
    }
    exit;
}

// 3. Generowanie Session ID i zapis zamówienia do bazy danych
$session_id = 'ORD-' . strtoupper(bin2hex(random_bytes(8))); // Krótsze, unikalne ID zamówienia

try {
    $stmt_insert = $pdo->prepare(
        "INSERT INTO orders (form_id, session_id, sender_name, sender_email, sender_phone, return_locker_id, amount, currency, payment_status, repair_status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'PLN', 'pending', 'new', NOW(), NOW())"
    );
    $stmt_insert->execute([
        $form_id, $session_id, $sender_name, $sender_email, $sender_phone, $return_locker_id, $db_price // Używaj ceny z bazy
    ]);
    // $order_id = $pdo->lastInsertId(); // Opcjonalnie, jeśli potrzebujesz ID liczbowego
} catch (\PDOException $e) {
    // Sprawdź, czy błąd to naruszenie unikalności session_id
    if ($e->getCode() == 23000) {
        error_log("DB Error inserting order (duplicate session_id?): " . $e->getMessage());
        $_SESSION['error_message'] = "Wystąpił chwilowy błąd podczas tworzenia zamówienia (ID conflict). Proszę spróbować ponownie.";
    } else {
        error_log("DB Error inserting order: " . $e->getMessage());
        $_SESSION['error_message'] = "Wystąpił błąd serwera podczas zapisywania zamówienia. Proszę skontaktować się z administratorem.";
    }
    header("Location: form.php?uuid=" . $form_uuid);
    exit;
}

// 4. Pobranie *aktywnej* konfiguracji P24 z bazy
//$p24_posId = get_active_setting('p24_pos_id', $pdo);
//$p24_crcKey = get_active_setting('p24_crc_key', $pdo);
//$p24_apiKey = get_active_setting('p24_api_key', $pdo);
//$p24_sandbox_enabled = get_setting('p24_sandbox_enabled', $pdo); // Pobierz tryb sandbox
// === TYMCZASOWE KLUCZE NA STAŁE (TEST) ===
$p24_posId = 265781;
$p24_crcKey = "e0d7ac6125600939";
$p24_apiKey = "404d485c25c140efee92436763a3fbe5";
$p24_sandbox_enabled = true; // Ustaw tryb sandbox na sztywno
// =========================================
// === DODANE LINIE LOGOWANIA ===
log_message("Odczytano ustawienia P24 dla p24_process.php:");
log_message(" - Tryb Sandbox włączony? " . ($p24_sandbox_enabled ? 'TAK' : 'NIE'));
log_message(" - Używany POS ID: " . ($p24_posId ? $p24_posId : 'BRAK DANYCH'));
log_message(" - Używany Klucz CRC: " . ($p24_crcKey ? substr($p24_crcKey, 0, 5) . '...' : 'BRAK DANYCH'));
//log_message(" - Używany Klucz API: " . ($p24_apiKey ? substr($p24_apiKey, 0, 5) . '...' : 'BRAK DANYCH'));
log_message(" - Używany Klucz API (pełny): " . ($p24_apiKey ? $p24_apiKey : 'BRAK DANYCH'));
// ===================================

$p24_apiUrlBase = $p24_sandbox_enabled ? "https://sandbox.przelewy24.pl/api/v1" : "https://secure.przelewy24.pl/api/v1";
$p24_redirectBase = $p24_sandbox_enabled ? "https://sandbox.przelewy24.pl/trnRequest/" : "https://secure.przelewy24.pl/trnRequest/";
$p24_registerUrl = $p24_apiUrlBase . '/transaction/register';

// === DODANE LOGOWANIE URL ===
log_message(" - Używany URL API P24 do rejestracji: " . $p24_registerUrl);
// =============================

// Sprawdzenie, czy aktywne klucze zostały pobrane
if (!$p24_posId || !$p24_crcKey || !$p24_apiKey) {
    $mode = $p24_sandbox_enabled ? 'sandbox' : 'production';
    error_log("Krytyczny błąd: Brak aktywnych kluczy API Przelewy24 ({$mode}) w bazie danych.");
    $_SESSION['error_message'] = "Błąd konfiguracji systemu płatności ({$mode}). Skontaktuj się z administratorem.";
    header("Location: form.php?uuid=" . $form_uuid);
    exit;
}

// Ustalenie pełnych adresów URL powrotu i statusu na podstawie nowej domeny
$appBaseUrl = "https://butolog.pl/zamowienie"; // <-- ZAKTUALIZOWANA DOMENA I FOLDER
$urlReturn = $appBaseUrl . '/p24_return.php';
$urlStatus = $appBaseUrl . '/p24_status.php';

// 5. Przygotowanie danych i podpisu ('sign') dla Przelewy24 API
$signData = [
    "sessionId" => $session_id,
    "merchantId" => (int)$p24_posId,
    "amount" => $amount_grosze,
    "currency" => "PLN",
    "crc" => $p24_crcKey
];

$sign = hash('sha384', json_encode($signData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

$requestPayload = [
    "merchantId" => (int)$p24_posId,
    "posId" => (int)$p24_posId,
    "sessionId" => $session_id,
    "amount" => $amount_grosze,
    "currency" => "PLN",
    "description" => $service_name . " (Zam: " . $session_id . ")",
    "email" => $sender_email,
    "client" => $sender_name,
    "country" => "PL",
    "language" => "pl",
    "urlReturn" => $urlReturn,
    "urlStatus" => $urlStatus,
    "sign" => $sign
];

// 6. Wywołanie API Przelewy24 za pomocą funkcji pomocniczej
log_message("P24 Register Request for sessionId {$session_id} (Mode: " . ($p24_sandbox_enabled ? 'Sandbox' : 'Production') . "): " . json_encode($requestPayload));
$p24Result = call_p24_api($p24_registerUrl, $p24_posId, $p24_apiKey, $requestPayload, 'POST');
log_message("P24 Register Response for sessionId {$session_id} (HTTP {$p24Result['http_code']}): " . $p24Result['response']);

// 7. Przetworzenie odpowiedzi z P24 i przekierowanie klienta
if ($p24Result['http_code'] == 200 && isset($p24Result['data']['data']['token'])) {
    $token = $p24Result['data']['data']['token'];
    $paymentLink = $p24_redirectBase . $token;
    log_message("P24 registration successful for sessionId {$session_id}. Token: {$token}. Redirecting to: {$paymentLink}");
    header("Location: " . $paymentLink);
    exit;
} else {
    // Błąd podczas rejestracji w P24
    $errorDetails = $p24Result['response'] ?? 'Brak odpowiedzi lub błąd połączenia z P24.';
    if(isset($p24Result['data']['error'])) { /* ... jak poprzednio ... */ }
    elseif(isset($p24Result['data']['errors'])) { /* ... jak poprzednio ... */ }
    elseif ($p24Result['http_code'] === 0) { /* ... jak poprzednio ... */ }

    error_log("P24 Register Error for sessionId {$session_id} (HTTP {$p24Result['http_code']}): " . $errorDetails);

    try {
        $stmt_cancel = $pdo->prepare("UPDATE orders SET payment_status = 'cancelled', updated_at = NOW() WHERE session_id = ?");
        $stmt_cancel->execute([$session_id]);
    } catch (\PDOException $e) { /* ... log ... */ }

    $_SESSION['error_message'] = "Nie udało się rozpocząć procesu płatności. Proszę spróbować ponownie lub skontaktować się z obsługą. Szczegóły techniczne: " . htmlspecialchars($errorDetails);
    header("Location: form.php?uuid=" . $form_uuid);
    exit;
}

?>