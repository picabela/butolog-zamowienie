<?php
// /zamowienie/admin/includes/header.php

// Upewnij się, że sesja jest aktywna
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Pobierz nazwę zalogowanego użytkownika (jeśli istnieje)
$admin_username = $_SESSION['admin_username'] ?? 'Gość'; // Domyślnie 'Gość', chociaż auth_check powinien to uniemożliwić

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Admina - BUTOLOG</title>
    <link rel="stylesheet" href="../assets/admin_style.css">
</head>
<body>
    <header>
        <h1>BUTOLOG - Panel Admina</h1>
        <nav>
            <?php if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true): ?>
                <span>Witaj, <?php echo htmlspecialchars($admin_username); ?>!</span>
                <a href="dashboard.php">Dashboard</a>
                <a href="forms.php">Formularze</a>
                <a href="orders.php">Zamówienia</a>
                <a href="settings.php">Ustawienia</a>
                <a href="logout.php">Wyloguj</a>
            <?php else: ?>
                <span>Panel Logowania</span>
            <?php endif; ?>
        </nav>
    </header>
    <main>


</body>
</html>