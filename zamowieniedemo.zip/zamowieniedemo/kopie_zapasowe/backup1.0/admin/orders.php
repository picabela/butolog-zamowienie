<?php
// /zamowienie/admin/orders.php

// Wymagaj sprawdzenia autoryzacji
require_once 'includes/auth_check.php';
// Wczytaj połączenie z bazą i funkcje pomocnicze
require_once '../includes/db.php';
require_once '../includes/functions.php'; // Może być potrzebne w przyszłości

$page_title = "Zarządzanie Zamówieniami"; // Ustaw tytuł strony
include 'includes/header.php'; // Wczytaj nagłówek HTML

// Zmienne do przechowywania komunikatów (jeśli będą potrzebne z innych akcji)
$success_message = $_SESSION['success_message'] ?? null;
$error_message = $_SESSION['error_message'] ?? null;
unset($_SESSION['success_message'], $_SESSION['error_message']);

// --- Pobieranie listy zamówień z bazy danych ---
try {
    // Łączymy tabelę orders z forms, aby uzyskać nazwę usługi
    $stmt = $pdo->query(
        "SELECT o.*, f.service_name
         FROM orders o
         JOIN forms f ON o.form_id = f.id
         ORDER BY o.created_at DESC" // Sortuj od najnowszych
    );
    $orders = $stmt->fetchAll();
} catch (\PDOException $e) {
    error_log("DB Error fetching orders list: " . $e->getMessage());
    $error_message = "Nie udało się pobrać listy zamówień.";
    $orders = []; // Ustaw pustą tablicę
}

?>

<h2><?php echo $page_title; ?></h2>

<?php if ($success_message): ?>
    <div class="success-message"><?php echo htmlspecialchars($success_message); ?></div>
<?php endif; ?>
<?php if ($error_message): ?>
    <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
<?php endif; ?>

<h3>Lista Zamówień</h3>
<?php if (!empty($orders)): ?>
    <table style="width: 100%; border-collapse: collapse;">
        <thead>
            <tr style="background-color: #f2f2f2;">
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">ID Zam. (Session)</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Data Utworzenia</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Klient</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Usługa</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Kwota</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: center;">Status Płatności</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: center;">Status Naprawy</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Nr Przesyłki InPost</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: center;">Akcje</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orders as $order): ?>
                <tr>
                    <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($order['session_id']); ?></td>
                    <td style="padding: 10px; border: 1px solid #ddd;"><?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></td>
                    <td style="padding: 10px; border: 1px solid #ddd;">
                        <?php echo htmlspecialchars($order['sender_name']); ?><br>
                        <small><?php echo htmlspecialchars($order['sender_email']); ?></small>
                    </td>
                    <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($order['service_name']); ?></td>
                    <td style="padding: 10px; border: 1px solid #ddd; text-align: right;"><?php echo number_format($order['amount'], 2, ',', ' '); ?> PLN</td>
                    <td style="padding: 10px; border: 1px solid #ddd; text-align: center;">
                        <?php echo htmlspecialchars(ucfirst($order['payment_status'])); // np. Pending, Paid ?>
                    </td>
                    <td style="padding: 10px; border: 1px solid #ddd; text-align: center;">
                        <?php echo htmlspecialchars(ucfirst($order['repair_status'])); // np. New, Label_generated ?>
                    </td>
                    <td style="padding: 10px; border: 1px solid #ddd;">
                        <?php if (!empty($order['inpost_tracking_number'])): ?>
                            <a href="https://inpost.pl/sledzenie-przesylek?number=<?php echo htmlspecialchars($order['inpost_tracking_number']); ?>" target="_blank">
                                <?php echo htmlspecialchars($order['inpost_tracking_number']); ?>
                            </a>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td style="padding: 10px; border: 1px solid #ddd; text-align: center; white-space: nowrap;">
                        <a href="view_order.php?id=<?php echo $order['id']; ?>" title="Zobacz szczegóły">👁️</a> |
                        <a href="edit_order_status.php?id=<?php echo $order['id']; ?>" title="Zmień status">✏️</a>
                        </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>Nie znaleziono żadnych zamówień.</p>
    <p>Gdy klient wypełni formularz naprawy i spróbuje dokonać płatności, zamówienie pojawi się tutaj ze statusem "pending".</p>
<?php endif; ?>

<?php
// Wczytaj stopkę HTML
include 'includes/footer.php';
?>