<?php
// /zamowienie/admin/forms.php

// Wymagaj sprawdzenia autoryzacji
require_once 'includes/auth_check.php';
// Wczytaj połączenie z bazą i funkcje pomocnicze
require_once '../includes/db.php';
require_once '../includes/functions.php'; // Potrzebna funkcja generate_uuid()

$page_title = "Zarządzanie Formularzami"; // Ustaw tytuł strony dla nagłówka
include 'includes/header.php'; // Wczytaj nagłówek HTML

// Zmienne do przechowywania komunikatów
$success_message = $_SESSION['success_message'] ?? null;
$error_message = $_SESSION['error_message'] ?? null;
// Usuń komunikaty z sesji po ich pobraniu
unset($_SESSION['success_message'], $_SESSION['error_message']);

// --- Logika obsługi dodawania nowego formularza ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_form') {
    // Prosta ochrona CSRF (można rozbudować o tokeny per sesja)
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
        $error_message = "Błąd CSRF Token. Odśwież stronę i spróbuj ponownie.";
    } else {
        // Pobierz i zwaliduj dane z formularza dodawania
        $service_name = filter_input(INPUT_POST, 'service_name', FILTER_SANITIZE_STRING);
        $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
        $is_active = isset($_POST['is_active']) ? 1 : 0; // Checkbox

        if (empty($service_name) || $price === false || $price <= 0) {
            $error_message = "Nazwa usługi i poprawna cena (większa od 0) są wymagane.";
        } else {
            // Wygeneruj unikalny UUID dla nowego formularza
            $uuid = generate_uuid();

            try {
                // Wstaw nowy formularz do bazy danych
                $stmt = $pdo->prepare("INSERT INTO forms (uuid, service_name, price, description, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())");
                $stmt->execute([$uuid, $service_name, $price, $description, $is_active]);
                $_SESSION['success_message'] = "Nowy formularz został pomyślnie dodany.";
                // Przekieruj, aby uniknąć ponownego wysłania formularza przy odświeżeniu
                header("Location: forms.php");
                exit;
            } catch (\PDOException $e) {
                error_log("DB Error inserting form: " . $e->getMessage());
                // Sprawdź czy błąd to duplikat UUID (bardzo mało prawdopodobne)
                if ($e->getCode() == 23000) {
                     $error_message = "Wystąpił błąd podczas generowania unikalnego ID. Spróbuj ponownie.";
                } else {
                    $error_message = "Wystąpił błąd serwera podczas dodawania formularza.";
                }
            }
        }
    }
}

// Wygeneruj token CSRF dla formularza dodawania (jeśli go nie ma)
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];


// --- Pobieranie listy istniejących formularzy ---
try {
    $stmt_list = $pdo->query("SELECT * FROM forms ORDER BY created_at DESC");
    $forms = $stmt_list->fetchAll();
} catch (\PDOException $e) {
    error_log("DB Error fetching forms list: " . $e->getMessage());
    $error_message = "Nie udało się pobrać listy formularzy.";
    $forms = []; // Ustaw pustą tablicę, aby uniknąć błędów niżej
}

?>

<h2><?php echo $page_title; ?></h2>

<?php if ($success_message): ?>
    <div class="success-message"><?php echo htmlspecialchars($success_message); ?></div>
<?php endif; ?>
<?php if ($error_message): ?>
    <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
<?php endif; ?>

<div class="add-form-section" style="margin-bottom: 30px; padding: 20px; background: #f9f9f9; border: 1px solid #eee; border-radius: 5px;">
    <h3>Dodaj Nowy Formularz Naprawy</h3>
    <form action="forms.php" method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
        <input type="hidden" name="action" value="add_form">

        <label for="service_name">Nazwa Usługi *</label>
        <input type="text" id="service_name" name="service_name" required placeholder="np. Wymiana fleków">

        <label for="price">Cena (PLN) *</label>
        <input type="number" id="price" name="price" step="0.01" min="0.01" required placeholder="np. 49.99">

        <label for="description">Opis (opcjonalny)</label>
        <textarea id="description" name="description" placeholder="Dodatkowy opis usługi widoczny dla admina"></textarea>

        <label for="is_active">
            <input type="checkbox" id="is_active" name="is_active" value="1" checked>
            Aktywny (link będzie działał dla klientów)
        </label>

        <button type="submit" class="button add-button">Dodaj Formularz</button>
    </form>
</div>


<h3>Istniejące Formularze</h3>
<?php if (!empty($forms)): ?>
    <table style="width: 100%; border-collapse: collapse;">
        <thead>
            <tr style="background-color: #f2f2f2;">
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">ID</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Link dla Klienta (UUID)</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Nazwa Usługi</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Cena</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: center;">Aktywny</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: center;">Akcje</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($forms as $form): ?>
                <tr>
                    <td style="padding: 10px; border: 1px solid #ddd;"><?php echo $form['id']; ?></td>
                    <td style="padding: 10px; border: 1px solid #ddd;">
                        <?php if ($form['is_active']): ?>
                            <a href="../form.php?uuid=<?php echo htmlspecialchars($form['uuid']); ?>" target="_blank" title="Otwórz link publiczny">
                                <?php echo htmlspecialchars($form['uuid']); ?>
                            </a>
                        <?php else: ?>
                            <span><?php echo htmlspecialchars($form['uuid']); ?></span> (nieaktywny)
                        <?php endif; ?>
                    </td>
                    <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($form['service_name']); ?></td>
                    <td style="padding: 10px; border: 1px solid #ddd; text-align: right;"><?php echo number_format($form['price'], 2, ',', ' '); ?> PLN</td>
                    <td style="padding: 10px; border: 1px solid #ddd; text-align: center;"><?php echo $form['is_active'] ? '✔️ Tak' : '❌ Nie'; ?></td>
                    <td style="padding: 10px; border: 1px solid #ddd; text-align: center; white-space: nowrap;">
                        <a href="edit_form.php?id=<?php echo $form['id']; ?>" title="Edytuj">✏️</a> |
                        <a href="toggle_form.php?id=<?php echo $form['id']; ?>" title="<?php echo $form['is_active'] ? 'Dezaktywuj' : 'Aktywuj'; ?>">
                            <?php echo $form['is_active'] ? '🚫' : '✅'; ?>
                        </a> |
                        <a href="delete_form.php?id=<?php echo $form['id']; ?>" onclick="return confirm('Czy na pewno chcesz usunąć ten formularz?');" title="Usuń">🗑️</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>Nie dodano jeszcze żadnych formularzy.</p>
<?php endif; ?>

<?php
// Wczytaj stopkę HTML
include 'includes/footer.php';
?>