<?php
// /zamowienie/admin/settings.php

// Wymagaj sprawdzenia autoryzacji
require_once 'includes/auth_check.php';
// Wczytaj połączenie z bazą i funkcje pomocnicze
require_once '../includes/db.php';
require_once '../includes/functions.php'; // Potrzebna funkcja log_message

$page_title = "Ustawienia Systemu"; // Ustaw tytuł strony
include 'includes/header.php'; // Wczytaj nagłówek HTML

// Zmienne do przechowywania komunikatów
$success_message = $_SESSION['success_message'] ?? null;
$error_message = $_SESSION['error_message'] ?? null;
unset($_SESSION['success_message'], $_SESSION['error_message']);

// --- Logika obsługi zapisywania ustawień ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_settings') {
    // Prosta ochrona CSRF
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
        $error_message = "Błąd CSRF Token. Odśwież stronę i spróbuj ponownie.";
    } else {
        // Pobierz wszystkie możliwe klucze ustawień z formularza
        $settings_to_update = [
            'p24_pos_id', 'p24_crc_key', 'p24_api_key', 'p24_sandbox_mode',
            'inpost_org_id', 'inpost_token', 'inpost_sandbox_mode',
            'service_receiver_name', 'service_receiver_email', 'service_receiver_phone', 'service_receiver_locker',
            'sender_name_override',
            'email_from_address', 'email_from_name'
        ];

        $errors = [];
        try {
            // Rozpocznij transakcję, aby zapisać wszystkie ustawienia naraz
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?");

            foreach ($settings_to_update as $key) {
                // Pobierz wartość z POST, obsłuż checkbox dla trybów sandbox
                if (str_ends_with($key, '_mode')) {
                    $value = isset($_POST[$key]) ? 'true' : 'false';
                } else {
                    // Użyj trim do usunięcia białych znaków z początku/końca
                    $value = isset($_POST[$key]) ? trim($_POST[$key]) : '';
                }

                // Prosta walidacja (można rozbudować)
                if (empty($value) && !in_array($key, ['sender_name_override', 'description'])) { // Pozwól na puste pole 'sender_name_override' i 'description' (jeśli dodasz)
                    // Pomiń aktualizację, jeśli kluczowe pole jest puste, chyba że to sandbox mode
                     if (!str_ends_with($key, '_mode')) {
                         log_message("Ostrzeżenie: Próba zapisu pustej wartości dla kluczowego ustawienia: {$key}. Pomijanie.");
                         // Można dodać $errors[] = "Ustawienie '$key' nie może być puste.";
                         continue; // Pomiń to ustawienie
                     }
                }

                // Zaktualizuj wartość w bazie
                $stmt->execute([$value, $key]);
            }

            // Zatwierdź transakcję
            $pdo->commit();
            $_SESSION['success_message'] = "Ustawienia zostały pomyślnie zaktualizowane.";
            // Odśwież stronę, aby pokazać nowe wartości i wyczyścić POST
            header("Location: settings.php");
            exit;

        } catch (\PDOException $e) {
            // Wycofaj transakcję w razie błędu
            $pdo->rollBack();
            error_log("DB Error updating settings: " . $e->getMessage());
            $error_message = "Wystąpił błąd serwera podczas zapisywania ustawień.";
        } catch (\Exception $e) { // Inne błędy
             $error_message = "Wystąpił błąd: " . $e->getMessage();
        }

        // Jeśli były błędy walidacji
        if (!empty($errors)) {
            $error_message = implode("<br>", $errors);
        }
    }
}

// Wygeneruj/pobierz token CSRF dla formularza
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// --- Pobieranie aktualnych ustawień z bazy do wyświetlenia w formularzu ---
$current_settings = [];
try {
    $stmt_get = $pdo->query("SELECT setting_key, setting_value FROM settings");
    while ($row = $stmt_get->fetch()) {
        $current_settings[$row['setting_key']] = $row['setting_value'];
    }
} catch (\PDOException $e) {
    error_log("DB Error fetching settings: " . $e->getMessage());
    $error_message = "Nie udało się pobrać aktualnych ustawień.";
    // Ustaw domyślne puste wartości, aby formularz się nie wysypał
    $keys = ['p24_pos_id', 'p24_crc_key', 'p24_api_key', 'p24_sandbox_mode', 'inpost_org_id', 'inpost_token', 'inpost_sandbox_mode', 'service_receiver_name', 'service_receiver_email', 'service_receiver_phone', 'service_receiver_locker', 'sender_name_override', 'email_from_address', 'email_from_name'];
    foreach ($keys as $key) { $current_settings[$key] = ''; }
}

// Funkcja pomocnicza do pobierania wartości ustawienia (z fallbackiem)
function get_current_setting($key, $settings_array, $default = '') {
    return isset($settings_array[$key]) ? htmlspecialchars($settings_array[$key]) : $default;
}
// Funkcja pomocnicza do sprawdzania checkboxa
function is_sandbox_mode($key, $settings_array) {
    return isset($settings_array[$key]) && strtolower(trim($settings_array[$key])) === 'true';
}

?>

<h2><?php echo $page_title; ?></h2>

<?php if ($success_message): ?>
    <div class="success-message"><?php echo htmlspecialchars($success_message); ?></div>
<?php endif; ?>
<?php if ($error_message): ?>
    <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
<?php endif; ?>

<p>W tym miejscu możesz skonfigurować klucze API oraz inne globalne parametry aplikacji.</p>

<form action="settings.php" method="POST">
    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
    <input type="hidden" name="action" value="save_settings">

    <fieldset style="margin-bottom: 20px; border: 1px solid #ccc; border-radius: 5px; padding: 15px;">
        <legend style="font-weight: bold; padding: 0 10px;">Ustawienia Przelewy24</legend>

        <label for="p24_pos_id">POS ID (ID Sprzedawcy)</label>
        <input type="text" id="p24_pos_id" name="p24_pos_id" value="<?php echo get_current_setting('p24_pos_id', $current_settings); ?>" required>

        <label for="p24_crc_key">Klucz CRC (do podpisu 'sign')</label>
        <input type="text" id="p24_crc_key" name="p24_crc_key" value="<?php echo get_current_setting('p24_crc_key', $current_settings); ?>" required>

        <label for="p24_api_key">Klucz API (do raportów / Basic Auth)</label>
        <input type="text" id="p24_api_key" name="p24_api_key" value="<?php echo get_current_setting('p24_api_key', $current_settings); ?>" required style="font-family: monospace;">

        <label for="p24_sandbox_mode">
            <input type="checkbox" id="p24_sandbox_mode" name="p24_sandbox_mode" value="true" <?php echo is_sandbox_mode('p24_sandbox_mode', $current_settings) ? 'checked' : ''; ?>>
            Tryb Sandbox (Testowy)
        </label>
        <small>Zaznacz, jeśli chcesz używać środowiska testowego Przelewy24.</small>
    </fieldset>

    <fieldset style="margin-bottom: 20px; border: 1px solid #ccc; border-radius: 5px; padding: 15px;">
        <legend style="font-weight: bold; padding: 0 10px;">Ustawienia InPost API (ShipX)</legend>

        <label for="inpost_org_id">ID Organizacji InPost</label>
        <input type="text" id="inpost_org_id" name="inpost_org_id" value="<?php echo get_current_setting('inpost_org_id', $current_settings); ?>" required>

        <label for="inpost_token">Token API InPost (Bearer)</label>
        <textarea id="inpost_token" name="inpost_token" required style="font-family: monospace; min-height: 100px;"><?php echo get_current_setting('inpost_token', $current_settings); ?></textarea>
        <small>Pamiętaj, aby regularnie odświeżać ten token, jeśli wygasa.</small>

        <label for="inpost_sandbox_mode">
            <input type="checkbox" id="inpost_sandbox_mode" name="inpost_sandbox_mode" value="true" <?php echo is_sandbox_mode('inpost_sandbox_mode', $current_settings) ? 'checked' : ''; ?>>
            Tryb Sandbox (Testowy)
        </label>
        <small>Zaznacz, jeśli chcesz używać środowiska testowego InPost.</small>
    </fieldset>

    <fieldset style="margin-bottom: 20px; border: 1px solid #ccc; border-radius: 5px; padding: 15px;">
        <legend style="font-weight: bold; padding: 0 10px;">Dane Odbiorcy (Serwisu Naprawczego)</legend>

        <label for="service_receiver_name">Nazwa odbiorcy (widoczna na etykiecie)</label>
        <input type="text" id="service_receiver_name" name="service_receiver_name" value="<?php echo get_current_setting('service_receiver_name', $current_settings); ?>" required>

        <label for="service_receiver_email">E-mail odbiorcy</label>
        <input type="email" id="service_receiver_email" name="service_receiver_email" value="<?php echo get_current_setting('service_receiver_email', $current_settings); ?>" required>

        <label for="service_receiver_phone">Telefon odbiorcy</label>
        <input type="tel" id="service_receiver_phone" name="service_receiver_phone" value="<?php echo get_current_setting('service_receiver_phone', $current_settings); ?>" required>

        <label for="service_receiver_locker">Docelowy Paczkomat odbiorcy (ID)</label>
        <input type="text" id="service_receiver_locker" name="service_receiver_locker" value="<?php echo get_current_setting('service_receiver_locker', $current_settings); ?>" required>
        <small>ID paczkomatu, do którego klienci będą wysyłać paczki.</small>
    </fieldset>

     <fieldset style="margin-bottom: 20px; border: 1px solid #ccc; border-radius: 5px; padding: 15px;">
        <legend style="font-weight: bold; padding: 0 10px;">Ustawienia Nadawcy i E-mail</legend>

        <label for="sender_name_override">Nadpisz nazwę nadawcy na etykiecie</label>
        <input type="text" id="sender_name_override" name="sender_name_override" value="<?php echo get_current_setting('sender_name_override', $current_settings); ?>">
        <small>Zostaw puste, aby użyć imienia i nazwiska klienta z formularza. Wpisz np. "BUTOLOG", aby zawsze używać tej nazwy.</small>

        <label for="email_from_address">Adres e-mail "Od" (w powiadomieniach)</label>
        <input type="email" id="email_from_address" name="email_from_address" value="<?php echo get_current_setting('email_from_address', $current_settings); ?>" required>

        <label for="email_from_name">Nazwa nadawcy "Od" (w powiadomieniach)</label>
        <input type="text" id="email_from_name" name="email_from_name" value="<?php echo get_current_setting('email_from_name', $current_settings); ?>" required>
     </fieldset>

    <button type="submit" class="button">Zapisz Ustawienia</button>
</form>

<?php
// Wczytaj stopkę HTML
include 'includes/footer.php';
?>