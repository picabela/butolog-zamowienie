<?php
// /zamowienie/form.php
require_once 'includes/db.php'; // Połączenie z bazą i funkcja get_setting()
require_once 'includes/functions.php'; // Funkcja generate_uuid() (chociaż tu niepotrzebna)

// Rozpocznij sesję, jeśli jeszcze nie jest aktywna (dla komunikatów o błędach z p24_process.php)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Pobierz UUID formularza z parametru GET w adresie URL
$form_uuid = $_GET['uuid'] ?? null;

if (!$form_uuid) {
    // Jeśli w URL nie ma ?uuid=..., wyświetl błąd
    die("Błąd: Brak identyfikatora formularza w adresie URL.");
}

// Pobierz dane konkretnego formularza z bazy danych
try {
    $stmt = $pdo->prepare("SELECT * FROM forms WHERE uuid = ? AND is_active = TRUE");
    $stmt->execute([$form_uuid]);
    $form = $stmt->fetch(); // Pobierz wiersz jako tablicę asocjacyjną
} catch (\PDOException $e) {
    error_log("DB Error fetching form (uuid: {$form_uuid}): " . $e->getMessage());
    die("Wystąpił błąd podczas ładowania formularza. Spróbuj odświeżyć stronę.");
}

// Sprawdź, czy formularz o danym UUID istnieje i jest aktywny
if (!$form) {
    die("Formularz nie został znaleziony, jest nieaktywny lub podany link jest nieprawidłowy.");
}

// Przygotuj dane do wyświetlenia (zabezpieczenie przed XSS)
$service_name = htmlspecialchars($form['service_name']);
$price_decimal = (float)$form['price']; // Upewnij się, że to liczba
$price_formatted = number_format($price_decimal, 2, ',', ' '); // Formatuj jako "123,45"
$form_id = $form['id']; // ID liczbowe, które przekażemy dalej

// Sprawdź, czy jest jakiś komunikat o błędzie z poprzedniej próby płatności
$error_message = null;
if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']); // Usuń komunikat po wyświetleniu
}

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zamówienie Naprawy: <?php echo $service_name; ?></title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <h1>Zamówienie naprawy: <?php echo $service_name; ?></h1>
        <p>Proszę wypełnić poniższe dane, aby opłacić usługę i wygenerować etykietę nadawczą InPost do wysłania Twojego obuwia do naszego serwisu.</p>

        <?php if ($error_message): ?>
            <div class="error">
                <strong>Wystąpił błąd:</strong><br>
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <div class="info-box">
            Całkowity koszt usługi: <strong><?php echo $price_formatted; ?> PLN</strong>
        </div>

        <form action="p24_process.php" method="POST">
            <input type="hidden" name="form_id" value="<?php echo $form_id; ?>">
            <input type="hidden" name="amount" value="<?php echo $price_decimal; ?>"> <input type="hidden" name="service_name" value="<?php echo $service_name; ?>"> <h2>Twoje dane (Nadawcy)</h2>
            <p>Podaj swoje dane kontaktowe. Zostaną one użyte jako dane nadawcy na etykiecie InPost oraz do wysłania powiadomień.</p>

            <label for="sender_name">Imię i nazwisko *</label>
            <input type="text" id="sender_name" name="sender_name" required placeholder="np. Jan Kowalski">

            <label for="sender_email">E-mail *</label>
            <input type="email" id="sender_email" name="sender_email" required placeholder="np. jan.kowalski@example.com">

            <label for="sender_phone">Telefon *</label>
            <input type="tel" id="sender_phone" name="sender_phone" required placeholder="np. 600123456">

            <h2>Paczkomat do zwrotu naprawy</h2>
            <p>Podaj identyfikator Paczkomatu InPost, do którego mamy odesłać naprawione obuwie.</p>

            <label for="return_locker_id">ID Twojego Paczkomatu *</label>
            <input type="text" id="return_locker_id" name="return_locker_id" required placeholder="np. KRA010">
            <small>Znajdź identyfikator na <a href="https://inpost.pl/znajdz-paczkomat" target="_blank">mapie InPost</a> (kliknij punkt na mapie).</small>

            <button type="submit" class="button">Opłać (<?php echo $price_formatted; ?> PLN) i Generuj Etykietę</button>
        </form>
    </div>
</body>
</html>