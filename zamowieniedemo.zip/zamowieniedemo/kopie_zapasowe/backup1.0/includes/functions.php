<?php
// /zamowienie/includes/functions.php
require_once __DIR__ . '/db.php'; // Upewnij się, że db.php jest załadowany

/**
 * Generuje unikalny identyfikator UUID v4.
 * @return string UUID v4.
 */
function generate_uuid() {
    try {
         $data = random_bytes(16);
         $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // v4
         $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // RFC 4122
         return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    } catch (Exception $e) { // Fallback
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
}

/**
 * Loguje wiadomość do pliku.
 * @param string $message Wiadomość.
 */
function log_message($message) {
    $log_file = __DIR__ . '/../status_log.txt';
    file_put_contents($log_file, date('Y-m-d H:i:s') . ' - ' . $message . "\n", FILE_APPEND);
}

/**
 * Pobiera *aktywne* ustawienie (sandbox lub production) na podstawie trybu.
 * @param string $base_key Klucz bazowy (np. 'p24_pos_id').
 * @param PDO $pdo_conn Połączenie PDO.
 * @return string|null Wartość ustawienia lub null.
 */
function get_active_setting(string $base_key, PDO $pdo_conn): ?string
{
    $sandbox_enabled = false;
    // Sprawdź odpowiedni tryb sandbox
    if (str_starts_with($base_key, 'p24_')) {
        $sandbox_enabled = get_setting('p24_sandbox_enabled', $pdo_conn);
    } elseif (str_starts_with($base_key, 'inpost_')) {
        $sandbox_enabled = get_setting('inpost_sandbox_enabled', $pdo_conn);
    } else {
        // Dla innych ustawień zwracamy wartość bezpośrednio
        return get_setting($base_key, $pdo_conn, false); // Trzeci argument false - nie konwertuj na boolean
    }

    $prefix = $sandbox_enabled ? 'sandbox_' : 'production_';
    // Usuń stary prefiks, jeśli istnieje (na wszelki wypadek) i dodaj nowy
    $key_without_prefix = preg_replace('/^(sandbox_|production_)/', '', $base_key);
    $active_key = $prefix . $key_without_prefix;

    return get_setting($active_key, $pdo_conn, false); // Pobierz wartość bez konwersji na boolean
}


/**
 * Pobiera *wszystkie* ustawienia jako tablicę asocjacyjną.
 * @param PDO $pdo_conn Połączenie PDO.
 * @return array Tablica ustawień [klucz => wartość].
 */
function get_all_settings(PDO $pdo_conn): array
{
    $settings = [];
    try {
        $stmt = $pdo_conn->query("SELECT setting_key, setting_value FROM settings");
        while ($row = $stmt->fetch()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    } catch (\PDOException $e) {
        error_log("DB Error fetching all settings: " . $e->getMessage());
        // Zwróć pustą tablicę w razie błędu
    }
    return $settings;
}

/**
 * Pomocnicza funkcja do pobierania wartości ustawienia z tablicy (dla formularza).
 * @param string $key Klucz ustawienia.
 * @param array $settings_array Tablica wszystkich ustawień.
 * @param string $default Wartość domyślna.
 * @return string Wartość (zabezpieczona htmlspecialchars).
 */
function get_current_setting_value(string $key, array $settings_array, string $default = ''): string
{
    return isset($settings_array[$key]) ? htmlspecialchars($settings_array[$key]) : $default;
}

/**
 * Pomocnicza funkcja do sprawdzania checkboxa trybu sandbox.
 * @param string $key Klucz ustawienia (np. 'p24_sandbox_enabled').
 * @param array $settings_array Tablica wszystkich ustawień.
 * @return bool True jeśli włączony, false w przeciwnym razie.
 */
function is_sandbox_enabled(string $key, array $settings_array): bool
{
    return isset($settings_array[$key]) && strtolower(trim($settings_array[$key])) === 'true';
}


// --- Funkcje API (pozostają bez zmian, używają get_active_setting) ---

function call_p24_api($url, $posId, $apiKey, $payload = [], $method = 'POST') {
    // ... (kod funkcji bez zmian) ...
    $ch = curl_init($url);
    $jsonData = json_encode($payload);
    $options = [ /* ... jak poprzednio ... */ ];
     if ($method === 'POST') { $options[CURLOPT_POST] = true; $options[CURLOPT_POSTFIELDS] = $jsonData; }
     elseif ($method === 'PUT') { $options[CURLOPT_CUSTOMREQUEST] = "PUT"; $options[CURLOPT_POSTFIELDS] = $jsonData; }
    curl_setopt_array($ch, $options);
    $response = curl_exec($ch); $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE); $error = curl_error($ch); curl_close($ch);
    if ($error) { log_message(/*...*/); return ['http_code' => 0, 'response' => $error, 'data' => null]; }
    $responseData = json_decode($response, true);
    return ['http_code' => $httpCode, 'response' => $response, 'data' => $responseData];
}

function call_inpost_api_post($url, $token, $payload) {
    // ... (kod funkcji bez zmian) ...
     $ch = curl_init($url);
     curl_setopt_array($ch, [ /* ... jak poprzednio ... */ CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . $token] ]);
     $response = curl_exec($ch); $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE); $error = curl_error($ch); curl_close($ch);
     if ($error) { log_message(/*...*/); return ['http_code' => 0, 'response' => $error, 'data' => null]; }
     $responseData = json_decode($response, true);
     return ['http_code' => $httpCode, 'response' => $response, 'data' => $responseData];
}

function call_inpost_api_get($url, $token) {
    // ... (kod funkcji bez zmian) ...
    $ch = curl_init($url);
    curl_setopt_array($ch, [ /* ... jak poprzednio ... */ CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token] ]);
    $response = curl_exec($ch); $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE); $error = curl_error($ch); curl_close($ch);
    if ($error) { log_message(/*...*/); return ['http_code' => 0, 'response' => $error, 'data' => null]; }
    $responseData = json_decode($response, true);
    return ['http_code' => $httpCode, 'response' => $response, 'data' => $responseData];
}

?>