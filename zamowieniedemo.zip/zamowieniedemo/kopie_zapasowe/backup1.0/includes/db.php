<?php
// includes/db.php
require_once 'config.php'; // Wczytaj dane dostępowe

$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Rzucaj wyjątki przy błędach SQL
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // Zwracaj wyniki jako tablice asocjacyjne
    PDO::ATTR_EMULATE_PREPARES   => false, // Używaj natywnych prepared statements
];

try {
     $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (\PDOException $e) {
     error_log("DB Connection Error: " . $e->getMessage()); // Loguj błąd
     // Wyświetl prosty komunikat użytkownikowi na produkcji
     die("Wystąpił krytyczny błąd aplikacji. Prosimy spróbować później.");
}

// Funkcja do pobierania ustawień z bazy
function get_setting($key, $pdo_conn) {
    try {
        $stmt = $pdo_conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetchColumn();

        // Prosta obsługa trybu sandbox (konwersja string 'true'/'false' na boolean)
        if (str_ends_with($key, '_mode') && $result !== false && $result !== null) {
            return strtolower(trim($result)) === 'true';
        }
        // Zwróć null jeśli nie znaleziono, zamiast false
        return ($result === false) ? null : $result;

    } catch (\PDOException $e) {
        error_log("Error fetching setting '{$key}': " . $e->getMessage());
        return null; // Zwróć null w przypadku błędu
    }
}
?>