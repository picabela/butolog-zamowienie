<?php
// includes/config.php

// --- DANE DOSTĘPOWE DO BAZY DANYCH ---
define('DB_HOST', 'localhost'); // Zazwyczaj localhost, chyba że masz inaczej
define('DB_NAME', 'host322698_butolog_zamowienie');
define('DB_USER', 'host322698_butolog_zamowienie');
define('DB_PASS', 'Wz392DKBhMSYh89nrBQP');
define('DB_CHARSET', 'utf8mb4');
// ------------------------------------

// --- INNE USTAWIENIA (można dodać później) ---
// np. define('APP_URL', 'https://adsarna.pl/zamowienie');

// Ustawienia raportowania błędów (zalecane dla developera)
// Na produkcji ustaw display_errors na 0 i loguj błędy do pliku
error_reporting(E_ALL);
ini_set('display_errors', 1); // Zmień na 0 na produkcji
ini_set('log_errors', 1);
ini_set('error_log', '../status_log.txt'); // Loguj błędy PHP do tego samego pliku co logi aplikacji

// Ustawienie strefy czasowej
date_default_timezone_set('Europe/Warsaw');

// Start sesji (potrzebne dla panelu admina i komunikatów)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>