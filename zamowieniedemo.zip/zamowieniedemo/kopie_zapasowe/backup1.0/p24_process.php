<?php
// /zamowienie/p24_process.php

// Wczytaj konfigurację, połączenie z bazą i funkcje pomocnicze
require_once 'includes/db.php';
require_once 'includes/functions.php';

// Upewnij się, że sesja jest aktywna (potrzebna do komunikatów o błędach)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Sprawdź, czy żądanie jest metodą POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    // Jeśli ktoś wszedł tu bezpośrednio przez GET, przekieruj
    header("Location: index.php");
    exit;
}

// 1. Walidacja i bezpieczne pobranie danych z formularza POST
$form_id = filter_input(INPUT_POST, 'form_id', FILTER_VALIDATE_INT);
$amount_from_form = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT); // Cena z formularza (do weryfikacji)
$service_name = filter_input(INPUT_POST, 'service_name', FILTER_SANITIZE_STRING); // Nazwa usługi (do opisu P24)
$sender_name = filter_input(INPUT_POST, 'sender_name', FILTER_SANITIZE_STRING);
$sender_email = filter_input(INPUT_POST, 'sender_email', FILTER_VALIDATE_EMAIL);
$sender_phone = filter_input(INPUT_POST, 'sender_phone', FILTER_SANITIZE_STRING);
// Podstawowa walidacja numeru telefonu (czy zawiera cyfry, opcjonalnie +, -, spacje)
$sender_phone = preg_replace('/[^+0-9]/', '', $sender_phone); // Usuń niechciane znaki
$return_locker_id = filter_input(INPUT_POST, 'return_locker_id', FILTER_SANITIZE_STRING);
// Prosta walidacja ID paczkomatu (np. 3 litery, 3 cyfry, opcjonalnie M)
$return_locker_id = strtoupper(preg_replace('/[^A-Z0-9]/i', '', $return_locker_id));

// Sprawdź, czy wszystkie wymagane pola są poprawne
if (!$form_id || $amount_from_form === false || !$service_name || !$sender_name || !$sender_email || empty($sender_phone) || empty($return_locker_id)) {
    $_SESSION['error_message'] = "Nieprawidłowe lub brakujące dane w formularzu. Proszę wypełnić wszystkie pola poprawnie.";
    // Potrzebujemy UUID formularza, żeby wrócić
    $stmt_uuid = $pdo->prepare("SELECT uuid FROM forms WHERE id = ?");
    $stmt_uuid->execute([$form_id ?? 0]); // Użyj 0 jeśli form_id jest niepoprawne
    $form_uuid_redirect = $stmt_uuid->fetchColumn();
    if ($form_uuid_redirect) {
        header("Location: form.php?uuid=" . $form_uuid_redirect);
    } else {
        header("Location: index.php"); // Fallback, jeśli nawet form_id było złe
    }
    exit;
}

// 2. Weryfikacja ceny z bazą danych (bardzo ważne!)
try {
    $stmt_form_check = $pdo->prepare("SELECT price, uuid FROM forms WHERE id = ? AND is_active = TRUE");
    $stmt_form_check->execute([$form_id]);
    $form_data = $stmt_form_check->fetch();

    if (!$form_data) {
        throw new Exception("Formularz nie istnieje lub jest nieaktywny.");
    }

    $db_price = (float)$form_data['price'];
    $form_uuid = $form_data['uuid']; // Pobierz UUID do ewentualnego powrotu z błędem

    // Porównaj cenę z formularza z ceną w bazie (tolerancja dla błędów float)
    if (abs($db_price - $amount_from_form) > 0.01) {
        throw new Exception("Niezgodność ceny przesłanej z formularza z ceną w bazie danych.");
    }
    $amount_grosze = (int) ($db_price * 100); // Używaj ceny z bazy!

} catch (\PDOException | \Exception $e) {
    error_log("Błąd weryfikacji formularza/ceny (form_id: {$form_id}): " . $e->getMessage());
    $_SESSION['error_message'] = "Wystąpił błąd podczas weryfikacji danych formularza. Spróbuj ponownie.";
    // Jeśli mamy UUID, wróć do formularza
    if (isset($form_uuid)) {
        header("Location: form.php?uuid=" . $form_uuid);
    } else {
        header("Location: index.php");
    }
    exit;
}

// 3. Generowanie Session ID i zapis zamówienia do bazy danych
$session_id = 'ORD-' . strtoupper(bin2hex(random_bytes(8))); // Krótsze, unikalne ID zamówienia

try {
    $stmt_insert = $pdo->prepare(
        "INSERT INTO orders (form_id, session_id, sender_name, sender_email, sender_phone, return_locker_id, amount, currency, payment_status, repair_status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'PLN', 'pending', 'new', NOW(), NOW())"
    );
    $stmt_insert->execute([
        $form_id, $session_id, $sender_name, $sender_email, $sender_phone, $return_locker_id, $db_price // Używaj ceny z bazy
    ]);
    // $order_id = $pdo->lastInsertId(); // Opcjonalnie, jeśli potrzebujesz ID liczbowego
} catch (\PDOException $e) {
    // Sprawdź, czy błąd to naruszenie unikalności session_id (mało prawdopodobne, ale możliwe)
    if ($e->getCode() == 23000) { 
        // Można spróbować wygenerować nowe ID i zapisać ponownie, lub zwrócić błąd
        error_log("DB Error inserting order (duplicate session_id?): " . $e->getMessage());
        $_SESSION['error_message'] = "Wystąpił chwilowy błąd podczas tworzenia zamówienia (ID conflict). Proszę spróbować ponownie.";
    } else {
        error_log("DB Error inserting order: " . $e->getMessage());
        $_SESSION['error_message'] = "Wystąpił błąd serwera podczas zapisywania zamówienia. Proszę skontaktować się z administratorem.";
    }
    header("Location: form.php?uuid=" . $form_uuid);
    exit;
}

// 4. Pobranie konfiguracji Przelewy24 z bazy
$p24_posId = get_setting('p24_pos_id', $pdo);
$p24_crcKey = get_setting('p24_crc_key', $pdo);
$p24_apiKey = get_setting('p24_api_key', $pdo);
$p24_sandbox_mode = get_setting('p24_sandbox_mode', $pdo);

// Sprawdzenie, czy klucze API są ustawione w bazie
if (!$p24_posId || !$p24_crcKey || !$p24_apiKey) {
    error_log("Krytyczny błąd: Brak konfiguracji API Przelewy24 w bazie danych (tabela settings).");
    $_SESSION['error_message'] = "Błąd konfiguracji systemu płatności. Proszę skontaktować się z administratorem.";
    header("Location: form.php?uuid=" . $form_uuid);
    exit;
}

// Ustalenie URL API i URL przekierowania na podstawie trybu sandbox/produkcja
$p24_apiUrlBase = $p24_sandbox_mode ? "https://sandbox.przelewy24.pl/api/v1" : "https://secure.przelewy24.pl/api/v1";
$p24_redirectBase = $p24_sandbox_mode ? "https://sandbox.przelewy24.pl/trnRequest/" : "https://secure.przelewy24.pl/trnRequest/";
$p24_registerUrl = $p24_apiUrlBase . '/transaction/register';

// Ustalenie pełnych adresów URL powrotu i statusu na podstawie nowej domeny
$appBaseUrl = "https://butolog.pl/zamowienie"; // <-- ZAKTUALIZOWANA DOMENA I FOLDER
$urlReturn = $appBaseUrl . '/p24_return.php';
$urlStatus = $appBaseUrl . '/p24_status.php';

// 5. Przygotowanie danych i podpisu ('sign') dla Przelewy24 API
$signData = [
    "sessionId" => $session_id,
    "merchantId" => (int)$p24_posId, // Dokumentacja P24 mówi, że merchantId jest int
    "amount" => $amount_grosze,     // Kwota w groszach jest int
    "currency" => "PLN",
    "crc" => $p24_crcKey           // Klucz CRC jest string
];

// Wygeneruj podpis SHA384
$sign = hash('sha384', json_encode($signData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

// Przygotuj pełny payload (ciało żądania) dla P24
$requestPayload = [
    "merchantId" => (int)$p24_posId,
    "posId" => (int)$p24_posId,
    "sessionId" => $session_id,
    "amount" => $amount_grosze,
    "currency" => "PLN",
    "description" => $service_name . " (Zam: " . $session_id . ")", // Opis widoczny dla klienta
    "email" => $sender_email,     // E-mail klienta
    "client" => $sender_name,      // Imię i nazwisko klienta
    "country" => "PL",
    "language" => "pl",           // Język interfejsu P24
    "urlReturn" => $urlReturn,     // Adres powrotu przeglądarki klienta
    "urlStatus" => $urlStatus,     // Adres dla powiadomień serwer-serwer (webhook)
    "sign" => $sign               // Wygenerowany podpis
];

// 6. Wywołanie API Przelewy24 za pomocą funkcji pomocniczej
log_message("P24 Register Request for sessionId {$session_id}: " . json_encode($requestPayload));
$p24Result = call_p24_api($p24_registerUrl, $p24_posId, $p24_apiKey, $requestPayload, 'POST');
log_message("P24 Register Response for sessionId {$session_id} (HTTP {$p24Result['http_code']}): " . $p24Result['response']);

// 7. Przetworzenie odpowiedzi z P24 i przekierowanie klienta
if ($p24Result['http_code'] == 200 && isset($p24Result['data']['data']['token'])) {
    // Sukces - otrzymano token
    $token = $p24Result['data']['data']['token'];
    $paymentLink = $p24_redirectBase . $token;

    log_message("P24 registration successful for sessionId {$session_id}. Token: {$token}. Redirecting to: {$paymentLink}");

    // Przekieruj przeglądarkę klienta na stronę płatności P24
    header("Location: " . $paymentLink);
    exit;
} else {
    // Błąd podczas rejestracji w P24
    $errorDetails = $p24Result['response'] ?? 'Brak odpowiedzi lub błąd połączenia z P24.';
    // Można spróbować pobrać komunikat błędu z JSONa, jeśli istnieje
    if(isset($p24Result['data']['error'])) {
        $errorDetails = "P24 Error: " . $p24Result['data']['error'] . " (Code: " . ($p24Result['data']['code'] ?? 'N/A') . ")";
    } elseif(isset($p24Result['data']['errors'])) {
        // Czasami P24 zwraca tablicę błędów walidacji
        $errorDetails = "P24 Validation Errors: " . json_encode($p24Result['data']['errors']);
    }

    error_log("P24 Register Error for sessionId {$session_id} (HTTP {$p24Result['http_code']}): " . $errorDetails);

    // Oznacz zamówienie jako anulowane lub nieudane (opcjonalnie)
    try {
        $stmt_cancel = $pdo->prepare("UPDATE orders SET payment_status = 'cancelled', updated_at = NOW() WHERE session_id = ?");
        $stmt_cancel->execute([$session_id]);
    } catch (\PDOException $e) {
        error_log("DB Error updating order status to cancelled for {$session_id}: " . $e->getMessage());
    }

    // Ustaw komunikat błędu i wróć do formularza
    $_SESSION['error_message'] = "Nie udało się rozpocząć procesu płatności. Proszę spróbować ponownie lub skontaktować się z obsługą. Szczegóły techniczne: " . htmlspecialchars($errorDetails);
    header("Location: form.php?uuid=" . $form_uuid);
    exit;
}

?>