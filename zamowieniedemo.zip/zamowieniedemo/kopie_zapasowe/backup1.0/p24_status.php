<?php
// /zamowienie/p24_status.php

// Ignoruj przerwanie połączenia przez klienta (P24), kontynuuj działanie skryptu
ignore_user_abort(true);
// Ustaw odpowiednio długi czas wykonywania skryptu (np. na próbę ponownego pobrania numeru śledzenia)
set_time_limit(120); // 2 minuty

require_once 'includes/db.php'; // Połączenie z bazą i funkcja get_setting()
require_once 'includes/functions.php'; // Funkcje pomocnicze, w tym call_p24_api() i call_inpost_api_*()

// --- Pobranie konfiguracji z bazy danych ---
$p24_posId = get_setting('p24_pos_id', $pdo);
$p24_crcKey = get_setting('p24_crc_key', $pdo);
$p24_apiKey = get_setting('p24_api_key', $pdo);
$p24_sandbox_mode = get_setting('p24_sandbox_mode', $pdo);
$p24_apiUrlBase = $p24_sandbox_mode ? "https://sandbox.przelewy24.pl/api/v1" : "https://secure.przelewy24.pl/api/v1";
$p24_verifyUrl = $p24_apiUrlBase . '/transaction/verify';

$inpost_org_id = get_setting('inpost_org_id', $pdo);
$inpost_token = get_setting('inpost_token', $pdo); // Pobiera token z bazy
$inpost_sandbox_mode = get_setting('inpost_sandbox_mode', $pdo);
$inpost_apiUrlBase = $inpost_sandbox_mode ? "https://sandbox-api-shipx-pl.easypack24.net/v1" : "https://api-shipx-pl.easypack24.net/v1";
$inpost_createShipmentUrl = $inpost_apiUrlBase . "/organizations/{$inpost_org_id}/shipments";
$inpost_getShipmentBaseUrl = $inpost_apiUrlBase . "/shipments/"; // Do pobierania danych przesyłki

$receiver_name = get_setting('service_receiver_name', $pdo);
$receiver_email = get_setting('service_receiver_email', $pdo);
$receiver_phone = get_setting('service_receiver_phone', $pdo);
$receiver_locker = get_setting('service_receiver_locker', $pdo);
$sender_name_override = get_setting('sender_name_override', $pdo); // Czy nadpisać nazwę nadawcy?
$email_from_address = get_setting('email_from_address', $pdo);
$email_from_name = get_setting('email_from_name', $pdo);
// ---------------------------------------------

// Sprawdzenie, czy wszystkie kluczowe ustawienia zostały wczytane
if (!$p24_posId || !$p24_crcKey || !$p24_apiKey || !$inpost_org_id || !$inpost_token || !$receiver_locker || !$email_from_address || !$email_from_name) {
    log_message("KRYTYCZNY BŁĄD w p24_status.php: Brak kluczowych ustawień w bazie danych (settings). Sprawdź klucze P24, InPost, dane odbiorcy i e-mail nadawcy.");
    // Odpowiedz P24, że coś jest nie tak po naszej stronie, ale nie ponawiaj (500)
    http_response_code(500); 
    exit("Internal Server Configuration Error"); 
}

// === KROK 1: Odbierz powiadomienie (webhook) od P24 ===
log_message("--- Nowe powiadomienie P24 [p24_status.php] ---");
$jsonInput = file_get_contents('php://input');
log_message("Odebrano dane P24: " . $jsonInput);
$p24WebhookData = json_decode($jsonInput, true);

// Podstawowa walidacja otrzymanych danych
if (!$p24WebhookData || !isset($p24WebhookData['orderId']) || !isset($p24WebhookData['sessionId']) || !isset($p24WebhookData['amount']) || !isset($p24WebhookData['currency'])) {
    log_message("Błąd P24 Webhook: Nieprawidłowe dane JSON lub brak kluczowych pól (orderId, sessionId, amount, currency).");
    http_response_code(400); // Bad Request - złe dane wejściowe
    exit("Invalid Webhook Data");
}

$session_id = $p24WebhookData['sessionId']; // Klucz do znalezienia zamówienia w naszej bazie

// === KROK 1.5: Sprawdź zamówienie w bazie danych ===
try {
    $stmt_check = $pdo->prepare("SELECT id, payment_status, sender_name, sender_email, sender_phone, return_locker_id FROM orders WHERE session_id = ?");
    $stmt_check->execute([$session_id]);
    $order = $stmt_check->fetch();

    if (!$order) {
        log_message("Błąd: Nie znaleziono zamówienia w bazie danych dla sessionId: " . $session_id);
        // Odpowiedz P24, że nie znaleziono - może to być testowe wywołanie lub błąd
        http_response_code(404); // Not Found
        exit("Order Not Found");
    }

    // Jeśli zamówienie już zostało opłacone i przetworzone, nie rób nic więcej, tylko odpowiedz OK
    if ($order['payment_status'] == 'paid' && $order['repair_status'] != 'new') { // Sprawdzamy też repair_status, na wszelki wypadek
         log_message("Informacja: Otrzymano powtórne powiadomienie dla już przetworzonego zamówienia sessionId: " . $session_id);
         http_response_code(200); // Już obsłużone, odpowiedz OK
         exit("OK - Already Processed");
    }

} catch (\PDOException $e) {
    error_log("DB Error checking order (sessionId: {$session_id}): " . $e->getMessage());
    http_response_code(500); // Błąd serwera po naszej stronie
    exit("Internal Server Error - DB Check");
}


// === KROK 2: Weryfikacja transakcji w Przelewy24 (OBOWIĄZKOWE) ===
log_message("Rozpoczynanie weryfikacji P24 dla sessionId: " . $session_id . ", P24 OrderID: " . $p24WebhookData['orderId']);

// Przygotuj dane do podpisu weryfikacji
$verifySignData = [
    "sessionId" => $session_id,
    "orderId" => (int)$p24WebhookData['orderId'],
    "amount" => (int)$p24WebhookData['amount'], // Użyj kwoty z powiadomienia do weryfikacji
    "currency" => $p24WebhookData['currency'],
    "crc" => $p24_crcKey
];
$verifySign = hash('sha384', json_encode($verifySignData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

// Przygotuj payload dla żądania weryfikacji
$verifyPayload = [
    "merchantId" => (int)$p24_posId,
    "posId" => (int)$p24_posId,
    "sessionId" => $session_id,
    "amount" => (int)$p24WebhookData['amount'],
    "currency" => $p24WebhookData['currency'],
    "orderId" => (int)$p24WebhookData['orderId'],
    "sign" => $verifySign
];

// Wywołaj API weryfikacji P24
$p24VerifyResult = call_p24_api($p24_verifyUrl, $p24_posId, $p24_apiKey, $verifyPayload, 'PUT');
log_message("Odpowiedź weryfikacji P24 (HTTP {$p24VerifyResult['http_code']}): " . $p24VerifyResult['response']);

// === KROK 3: Płatność zweryfikowana - Przejdź do InPost i Email ===
if ($p24VerifyResult['http_code'] == 200 && isset($p24VerifyResult['data']['data']['status']) && $p24VerifyResult['data']['data']['status'] == 'success') {
    log_message("Weryfikacja P24 Pomyślna dla sessionId: {$session_id}");

    // Oznacz zamówienie w bazie jako opłacone (jeśli jeszcze nie jest)
    try {
        $stmt_update_paid = $pdo->prepare("UPDATE orders SET payment_status = 'paid', p24_order_id = ?, updated_at = NOW() WHERE session_id = ? AND payment_status = 'pending'");
        $updatedRows = $stmt_update_paid->execute([$p24WebhookData['orderId'], $session_id]);
        if ($updatedRows == 0 && $order['payment_status'] != 'paid') {
            // Sytuacja awaryjna - nie udało się zaktualizować statusu, chociaż weryfikacja przeszła
             log_message("OSTRZEŻENIE: Weryfikacja P24 pomyślna, ale nie udało się zaktualizować statusu w bazie dla sessionId: {$session_id}. Sprawdź zamówienie ręcznie!");
             // Można by tu spróbować jeszcze raz lub wysłać alert admina
        }
    } catch (\PDOException $e) {
        error_log("DB Error updating order to paid for {$session_id}: " . $e->getMessage());
        // W tym miejscu można rozważyć, czy kontynuować, czy zwrócić błąd 500
        // Na razie kontynuujemy próbę wygenerowania etykiety
    }

    // Sprawdź, czy etykieta nie została już przypadkiem wygenerowana (np. przez poprzednie, nieudane wywołanie)
    $stmt_check_inpost = $pdo->prepare("SELECT inpost_shipment_id FROM orders WHERE session_id = ?");
    $stmt_check_inpost->execute([$session_id]);
    $existing_shipment_id = $stmt_check_inpost->fetchColumn();

    if ($existing_shipment_id) {
        log_message("Informacja: Etykieta InPost dla sessionId {$session_id} została już wcześniej wygenerowana (ID: {$existing_shipment_id}). Pomijanie tworzenia nowej.");
        // W tym miejscu można by ewentualnie ponownie wysłać e-mail, jeśli byłby potrzebny
    } else {
        // --- Generowanie Etykiety InPost ---
        log_message("Rozpoczynanie generowania etykiety InPost dla sessionId: {$session_id}");

        // Ustal nazwę nadawcy
        $sender_name_inpost = !empty($sender_name_override) ? $sender_name_override : $order['sender_name'];
        $sender_company_name_inpost = $sender_name_inpost; // Użyj tego samego dla obu pól

        // Przygotuj payload dla API InPost
        $inpostCreateUrl = $inpost_apiUrlBase . "/organizations/{$inpost_org_id}/shipments";
        $inpostPayload = [
            'receiver' => ['name' => $receiver_name, 'email' => $receiver_email, 'phone' => $receiver_phone],
            'sender' => ['name' => $sender_name_inpost, 'company_name' => $sender_company_name_inpost, 'email' => $order['sender_email'], 'phone' => $order['sender_phone']],
            'parcels' => [['template' => 'medium']], // Gabaryt B
            'service' => 'inpost_locker_standard',
            'reference' => $session_id, // Nasze ID zamówienia jako referencja
            'comments' => 'Naprawa obuwia (Zam: ' . $session_id . ')',
            'sending_method' => 'any_point', // Sposób nadania na głównym poziomie
            'custom_attributes' => [
                'target_point' => $receiver_locker, // Paczkomat szewca
                'sending_method' => 'any_point' // Sposób nadania w atrybutach
            ]
        ];
        log_message("Wysyłanie żądania utworzenia przesyłki InPost: " . json_encode($inpostPayload));

        // Wywołaj API InPost (POST)
        $inpostCreateResult = call_inpost_api_post($inpostCreateUrl, $inpost_token, $inpostPayload);
        log_message("Odpowiedź InPost (tworzenie) (HTTP {$inpostCreateResult['http_code']}): " . $inpostCreateResult['response']);
        $inpostCreateResponse = $inpostCreateResult['data']; // Użyj zdekodowanych danych

        // Przetwórz odpowiedź InPost
        if ($inpostCreateResult['http_code'] == 201 && isset($inpostCreateResponse['id'])) {
            $shipmentId = $inpostCreateResponse['id'];
            $trackingNumber = $inpostCreateResponse['tracking_number'] ?? null; // Może być null na początku
            // Spróbuj pobrać target_point z odpowiedzi, fallback na konfigurację
            $targetLocker = $inpostCreateResponse['custom_attributes']['target_point'] ?? ($inpostCreateResponse['target_point'] ?? $receiver_locker);

            log_message("Sukces InPost! Utworzono przesyłkę. ID: {$shipmentId}, Tracking (początkowy): {$trackingNumber}, Docelowy Paczkomat: {$targetLocker}");

            // Spróbuj pobrać numer śledzenia ponownie po chwili, jeśli był null
            if (empty($trackingNumber)) {
                log_message("Numer śledzenia pusty/null. Czekam 5 sekund i pobieram ponownie...");
                sleep(5);
                $inpostGetShipmentUrl = $inpost_apiUrlBase . "/shipments/{$shipmentId}";
                $inpostGetResult = call_inpost_api_get($inpostGetShipmentUrl, $inpost_token);
                log_message("Odpowiedź InPost (GET /shipments/{$shipmentId}) (HTTP {$inpostGetResult['http_code']}): " . $inpostGetResult['response']);

                if ($inpostGetResult['http_code'] == 200 && isset($inpostGetResult['data']['tracking_number'])) {
                    $trackingNumber = $inpostGetResult['data']['tracking_number'];
                    log_message("Pobrano zaktualizowany numer śledzenia: {$trackingNumber}");
                } else {
                    log_message("Nie udało się pobrać zaktualizowanych danych przesyłki lub numer śledzenia nadal nie jest dostępny.");
                    $trackingNumber = 'Oczekuje na nadanie';
                }
            }

            // Zaktualizuj zamówienie w bazie danych o dane InPost
            try {
                $stmt_update_inpost = $pdo->prepare("UPDATE orders SET inpost_shipment_id = ?, inpost_tracking_number = ?, repair_status = 'label_generated', updated_at = NOW() WHERE session_id = ?");
                $stmt_update_inpost->execute([$shipmentId, ($trackingNumber == 'Oczekuje na nadanie' ? null : $trackingNumber), $session_id]);
            } catch (\PDOException $e) {
                error_log("DB Error updating order with InPost data for {$session_id}: " . $e->getMessage());
                // Rozważ wysłanie alertu do admina
            }

            // Wyślij e-mail do klienta
            $labelDownloadPageLink = "https://butolog.pl/zamowienie/download_page.php?shipment_id=" . $shipmentId; // Poprawny link
            $customerEmail = $order['sender_email'];
            $customerName = $order['sender_name'];
            $returnLockerId = $order['return_locker_id'];
            $amountPaid = number_format($p24WebhookData['amount'] / 100, 2, ',', '');
            $currency = $p24WebhookData['currency'];

            $subject = "Potwierdzenie opłaty i etykieta nadawcza {$email_from_name} (Zam: {$sessionId})";
            $message = "Witaj {$customerName},\n\n"
                     . "Dziękujemy za opłacenie usługi naprawy obuwia (Zamówienie: {$sessionId}) w {$email_from_name}.\n\n"
                     . "Status płatności: OPŁACONE\n"
                     . "Kwota: {$amountPaid} {$currency}\n\n"
                     . "--- ETYKIETA NADAWCZA INPOST ---\n\n"
                     . "Wygenerowaliśmy dla Ciebie etykietę, abyś mógł wysłać do nas swoje buty.\n\n"
                     . "**Strona do pobrania etykiety (PDF):**\n"
                     . $labelDownloadPageLink . "\n\n"
                     . "**Numer przesyłki (śledzenia) do nas:** {$trackingNumber}\n\n"
                     . "Prosimy o nadanie paczki w dowolnym paczomacie lub PaczkoPunkcie. Została ona zaadresowana do naszego paczkomatu: {$targetLocker}.\n\n"
                     . "--- DANE ZWROTNE ---\n"
                     . "Po naprawie odeślemy buty do wskazanego przez Ciebie paczkomatu: {$returnLockerId}.\n\n"
                     . "Pozdrawiamy,\n"
                     . "Zespół {$email_from_name}";

            $headers = "From: {$email_from_name} <{$email_from_address}>\r\n"
                     . "Reply-To: {$email_from_address}\r\n" // Użyj tego samego adresu do odpowiedzi
                     . "Content-Type: text/plain; charset=UTF-8\r\n"
                     . "X-Mailer: PHP/" . phpversion();

            if (mail($customerEmail, $subject, $message, $headers)) {
                log_message("Pomyślnie wysłano e-mail dla sessionId: {$session_id} na adres: " . $customerEmail);
            } else {
                log_message("BŁĄD: mail() nie powiodło się dla sessionId: {$session_id}. Sprawdź konfigurację serwera pocztowego.");
                error_log("PHP Mail Error: Failed to send email to {$customerEmail} for session {$session_id}");
                // Można dodać alert dla admina
            }

        } else {
            // Błąd podczas tworzenia przesyłki InPost
            $errorResponse = $inpostCreateResult['response'] ?? 'Brak odpowiedzi InPost';
            log_message("BŁĄD KRYTYCZNY INPOST dla sessionId: {$session_id}. Nie udało się wygenerować etykiety. Odpowiedź (HTTP {$inpostCreateResult['http_code']}): " . $errorResponse);
            // Zaktualizuj status zamówienia w bazie, aby wskazywał na błąd
            try {
                $stmt_update_error = $pdo->prepare("UPDATE orders SET repair_status = 'cancelled', payment_status = 'paid', updated_at = NOW() WHERE session_id = ?");
                $stmt_update_error->execute([$session_id]);
            } catch (\PDOException $e) {
                error_log("DB Error updating order status to cancelled after InPost error for {$session_id}: " . $e->getMessage());
            }
            // TODO: Wyślij powiadomienie do admina o błędzie generowania etykiety!
        }
    } // Koniec bloku 'if (!$existing_shipment_id)'

} else {
    // Weryfikacja P24 nie powiodła się
    log_message("Błąd weryfikacji P24 dla sessionId: {$session_id}. Odpowiedź P24: " . $p24VerifyResult['response']);
    // Zaktualizuj status zamówienia w bazie
    try {
         $stmt_update_failed = $pdo->prepare("UPDATE orders SET payment_status = 'failed', updated_at = NOW() WHERE session_id = ? AND payment_status = 'pending'");
         $stmt_update_failed->execute([$session_id]);
    } catch (\PDOException $e) {
         error_log("DB Error updating order status to failed for {$session_id}: " . $e->getMessage());
    }
}

// === KROK 4: Zawsze odpowiedz P24 kodem 200 OK ===
// To potwierdza odbiór powiadomienia i zapobiega jego ponownemu wysyłaniu.
http_response_code(200);
echo "OK";
exit;

?>