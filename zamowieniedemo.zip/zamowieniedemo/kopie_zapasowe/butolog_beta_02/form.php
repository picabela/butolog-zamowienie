<?php
// /zamowienie/form.php
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }

$form_uuid = $_GET['uuid'] ?? null;
if (!$form_uuid) { die("Błąd: Brak identyfikatora formularza."); }

try {
    $stmt = $pdo->prepare("SELECT * FROM forms WHERE uuid = ? AND is_active = TRUE");
    $stmt->execute([$form_uuid]);
    $form = $stmt->fetch();
} catch (\PDOException $e) {
    error_log("DB Error fetching form (uuid: {$form_uuid}): " . $e->getMessage());
    die("Wystąpił błąd podczas ładowania formularza.");
}

if (!$form) { die("Formularz nie znaleziony lub nieaktywny."); }

$service_name = htmlspecialchars($form['service_name']);
$price_decimal = (float)$form['price'];
$price_formatted = number_format($price_decimal, 2, ',', ' ');
$form_id = $form['id'];

$error_message = $_SESSION['error_message'] ?? null;
unset($_SESSION['error_message']);

// --- Token Geowidget (wstawiony Twój!) ---
$geowidget_token = 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJkVzROZW9TeXk0OHpCOHg4emdZX2t5dFNiWHY3blZ0eFVGVFpzWV9TUFA4In0.eyJleHAiOjIwNTc5NjIxMjUsImlhdCI6MTc0MjYwMjEyNSwianRpIjoiZGE3ZDA1MDMtNThmZC00OWQwLWE3YWEtMmZlMzQ4YjcyODc0IiwiaXNzIjoiaHR0cHM6Ly9zYW5kYm94LWxvZ2luLmlucG9zdC5wbC9hdXRoL3JlYWxtcy9leHRlcm5hbCIsInN1YiI6ImY6N2ZiZjQxYmEtYTEzZC00MGQzLTk1ZjYtOThhMmIxYmFlNjdiOjR2UlJaSDZHNW1LUWdTa2FQXy0yWFVKd19pT0hvTUIwMDF1aGE4SE5aVzAiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJzaGlweCIsInNlc3Npb25fc3RhdGUiOiJlZTc2YTAyYi01YWMyLTQzOGYtOGZmNi1hOWQ5NzliMzFlODkiLCJzY29wZSI6Im9wZW5pZCBhcGk6YXBpcG9pbnRzIiwic2lkIjoiZWU3NmEwMmItNWFjMi00MzhmLThmZjYtYTlkOTc5YjMxZTg5IiwiYWxsb3dlZF9yZWZlcnJlcnMiOiJ0ZXN0LnBsIiwidXVpZCI6IjMxNzAwYmU3LTA2ZTAtNGVkZC05NTA1LTAzZjJhZjQ3M2QwMiJ9.GLoh6yMmqbC1tfI52hLVsxGIT80d0NQYlSU6NThVjM1TaEpCFGhQ_7F4skTjTGRX8CzdlUIkh4N0L-78KhboUGGaIn2DKc6bXMqB5YMOt_RMsDPXE3l0QGHrfndX9b9wxVdfDvGvM06R1Fcn_8l8alLRXrRhlY4GqWVzRzyC5rJjr4QkmPIZ2EvXB5DQoTStSUfcgWSzEhUGc499-TLsrztIb9DuyC_VSB3zo3D0bNX6NtbcYfOAK3Q4IGh2lj9DmSV9tW6aVj_QjHz-plstruTdg7vc6gK3vguPYY-55aQSJuO9ZHnx9rHvIcgdnx-7BVOBj84pviSqm2tiPcgZwg';
// ----------------------------------------

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zamówienie Naprawy: <?php echo $service_name; ?></title>
    <link rel="stylesheet" href="assets/style.css">

    <!-- Skrypty i Style Geowidgetu (sandbox) -->
    <link rel="stylesheet" href="https://sandbox-global-geowidget-sdk.easypack24.net/inpost-geowidget.css"/>
    <script src='https://sandbox-global-geowidget-sdk.easypack24.net/inpost-geowidget.js' defer></script>

    <style>
        /* Styl dla kontenera Geowidgetu */
        #geowidget-container-inline {
            margin-top: 10px; border: 1px solid #d7ccc8; border-radius: 6px;
            padding: 5px; min-height: 450px; height: 60vh;
            position: relative; /* Potrzebne do pozycjonowania overlay */
            overflow: hidden; /* Ukryj ewentualne paski przewijania widgetu */
        }
        /* Informacja o wybranym punkcie */
        #selected-point-info {
            margin-top: 15px; padding: 12px; background-color: #efebe9;
            border: 1px solid #d7ccc8; border-radius: 6px; font-size: 0.95em;
            color: #5d4037; display: block; text-align: left; /* Zawsze widoczne */
            position: relative; /* Dla linku reset */
        }
        #selected-point-info strong { display: block; margin-bottom: 5px; font-weight: 600; }
        #selected-point-info.selected { background-color: #dcedc8; border-color: #c5e1a5; color: #33691e; }

        /* === NOWY STYL DLA LINKU RESET === */
        #reset-selection-link {
            position: absolute;
            top: 8px; /* Dopasuj pozycję */
            right: 10px;
            font-size: 0.85em;
            color: var(--link-color, #795548);
            text-decoration: underline;
            cursor: pointer;
            display: none; /* Ukryty domyślnie */
        }
        #selected-point-info.selected #reset-selection-link {
            display: inline; /* Pokaż tylko gdy punkt jest wybrany */
        }
        #reset-selection-link:hover {
            color: var(--primary-color, #5d4037);
        }
        /* ================================ */

        /* Komunikat o konieczności wyboru */
        #locker-error-message { color: #c62828; font-size: 0.9em; margin-top: 5px; display: none; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Zamówienie naprawy: <?php echo $service_name; ?></h1>
        <p>Proszę wypełnić poniższe dane...</p>

        <?php if ($error_message): ?>
            <div class="error"><strong>Wystąpił błąd:</strong><br><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <div class="info-box">Całkowity koszt usługi: <strong><?php echo $price_formatted; ?> PLN</strong></div>

        <form action="p24_process.php" method="POST" id="repairForm">
            <input type="hidden" name="form_id" value="<?php echo $form_id; ?>">
            <input type="hidden" name="amount" value="<?php echo $price_decimal; ?>">
            <input type="hidden" name="service_name" value="<?php echo $service_name; ?>">
            <input type="hidden" name="return_locker_id" id="selected_locker_id" value="">

            <h2>Twoje dane (Nadawcy)</h2>
            <p>Podaj swoje dane kontaktowe.</p>
            <label for="sender_name">Imię i nazwisko *</label>
            <input type="text" id="sender_name" name="sender_name" required placeholder="np. Jan Kowalski">
            <label for="sender_email">E-mail *</label>
            <input type="email" id="sender_email" name="sender_email" required placeholder="np. jan.kowalski@example.com">
            <label for="sender_phone">Telefon *</label>
            <input type="tel" id="sender_phone" name="sender_phone" required placeholder="np. 600123456">

            <h2>Paczkomat do zwrotu naprawy *</h2>
            <p>Wybierz na mapie Paczkomat InPost, do którego mamy odesłać naprawione obuwie.</p>

            <!-- Miejsce na wyświetlenie informacji o wybranym punkcie -->
            <div id="selected-point-info">
                Nie wybrano punktu.
                <!-- === NOWY LINK RESET === -->
                <span id="reset-selection-link">Usuń wybór</span>
                <!-- ===================== -->
            </div>

            <!-- Kontener na Geowidget -->
            <div id="geowidget-container-inline">
                <inpost-geowidget
                    id="geowidget-inline"
                    token="<?php echo htmlspecialchars($geowidget_token); ?>"
                    language="pl"
                    country="PL"
                    config="parcelCollect"
                    onpoint="afterPointSelected">
                 </inpost-geowidget>
            </div>

            <div id="locker-error-message">Proszę wybrać paczkomat.</div>

            <button type="submit" class="button">Opłać (<?php echo $price_formatted; ?> PLN) i Generuj Etykietę</button>
        </form>
    </div>

    <!-- Skrypt JavaScript -->
    <script>
      const selectedLockerIdInput = document.getElementById('selected_locker_id');
      const selectedPointInfoDiv = document.getElementById('selected-point-info');
      const lockerErrorMessage = document.getElementById('locker-error-message');
      const repairForm = document.getElementById('repairForm');
      const geowidgetElement = document.getElementById('geowidget-inline'); // Zapisz referencję do widgetu
      const resetLink = document.getElementById('reset-selection-link');
      let geowidgetApi = null; // Zmienna na API widgetu

       // Nasłuchuj na inicjalizację widgetu, aby pobrać API
       if (geowidgetElement) {
           geowidgetElement.addEventListener('inpost.geowidget.init', (event) => {
               if(event.detail && event.detail.api) {
                  geowidgetApi = event.detail.api;
                  console.log("Geowidget API zainicjalizowane.");
               }
           });
       }

      // Funkcja obsługująca wybór punktu
      function afterPointSelected(point) {
        console.log('Wybrano punkt:', point);

        if (point && point.name) {
          selectedLockerIdInput.value = point.name; // Zapisz ID

          let infoHtml = `<strong>Wybrany Paczkomat: ${point.name}</strong>`;
          if (point.address_details) {
              infoHtml += `${point.address_details.street || ''} ${point.address_details.building_number || ''}<br>`;
              infoHtml += `${point.address_details.post_code || ''} ${point.address_details.city || ''}`;
          } else if (point.location_description) {
               infoHtml += `${point.location_description}`;
          }
          // Dodaj link reset wewnątrz diva
          infoHtml += '<span id="reset-selection-link">Usuń wybór</span>';

          selectedPointInfoDiv.innerHTML = infoHtml;
          selectedPointInfoDiv.style.display = 'block';
          selectedPointInfoDiv.classList.add('selected');
          lockerErrorMessage.style.display = 'none';

          // Ponownie podepnij event listener do nowego linku reset
          const newResetLink = document.getElementById('reset-selection-link');
          if(newResetLink) {
              newResetLink.addEventListener('click', resetPointSelection);
          }

        } else {
          // Błąd - wyczyść
          selectedLockerIdInput.value = '';
          selectedPointInfoDiv.innerHTML = 'Wystąpił błąd podczas wyboru punktu. <span id="reset-selection-link">Usuń wybór</span>'; // Dodaj też link resetu
          selectedPointInfoDiv.style.display = 'block';
          selectedPointInfoDiv.classList.remove('selected');
           // Ponownie podepnij event listener do nowego linku reset
           const errorResetLink = document.getElementById('reset-selection-link');
           if(errorResetLink) { errorResetLink.style.display = 'none'; } // Ukryj w razie błędu? Może lepiej zostawić?
          console.error('Otrzymano nieprawidłowe dane punktu z Geowidget.');
        }
      }

        // === NOWA FUNKCJA RESETOWANIA ===
        function resetPointSelection(event) {
            if(event) event.preventDefault(); // Zapobiegaj domyślnej akcji linku

            selectedLockerIdInput.value = ''; // Wyczyść ukryte pole
            selectedPointInfoDiv.innerHTML = 'Nie wybrano punktu. <span id="reset-selection-link">Usuń wybór</span>'; // Przywróć tekst i link (ale ukryty przez CSS)
            selectedPointInfoDiv.classList.remove('selected'); // Usuń zielone tło
            lockerErrorMessage.style.display = 'none'; // Ukryj komunikat błędu

            // Spróbuj zresetować widok widgetu za pomocą API
            if (geowidgetApi && typeof geowidgetApi.clearPoint === 'function') {
                try {
                    geowidgetApi.clearPoint(); // Wywołaj metodę API do wyczyszczenia punktu
                    console.log("Wywołano geowidgetApi.clearPoint()");
                } catch (e) {
                    console.error("Błąd podczas wywoływania geowidgetApi.clearPoint():", e);
                     // Fallback: Jeśli API zawiedzie, można spróbować przeładować widget (bardziej inwazyjne)
                     // recreateGeowidget();
                }
            } else {
                 console.warn("API Geowidgetu nie jest dostępne lub nie ma metody clearPoint(). Resetowanie widoku może nie działać w pełni.");
                 // Można dodać fallback recreateGeowidget();
            }
        }
        // ================================

      // Podpięcie event listenera do linku reset przy ładowaniu strony (na wszelki wypadek)
      const initialResetLink = document.getElementById('reset-selection-link');
       if(initialResetLink) {
          initialResetLink.addEventListener('click', resetPointSelection);
       }


      // Walidacja formularza przed wysłaniem (bez zmian)
      if (repairForm) {
          repairForm.addEventListener('submit', function(event) {
              if (!selectedLockerIdInput.value) {
                  lockerErrorMessage.style.display = 'block';
                  event.preventDefault();
                  if (geowidgetContainer) {
                      geowidgetContainer.scrollIntoView({ behavior: 'smooth', block: 'center' });
                  }
                  alert('Proszę wybrać Paczkomat zwrotny na mapie.');
              } else {
                  lockerErrorMessage.style.display = 'none';
              }
          });
      }
    </script>
</body>
</html>