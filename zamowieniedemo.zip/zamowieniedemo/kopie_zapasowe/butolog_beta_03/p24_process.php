<?php
// /zamowienie/p24_process.php

// Wczytaj konfigurację, połączenie z bazą i funkcje pomocnicze
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

// 1. Walidacja i pobranie danych z formularza POST
$form_id = filter_input(INPUT_POST, 'form_id', FILTER_VALIDATE_INT);
$amount_from_form = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT); // Otrzymana cena końcowa
$service_name = filter_input(INPUT_POST, 'service_name', FILTER_DEFAULT);
$sender_name = filter_input(INPUT_POST, 'sender_name', FILTER_DEFAULT);
$sender_email = filter_input(INPUT_POST, 'sender_email', FILTER_VALIDATE_EMAIL);
$sender_phone = filter_input(INPUT_POST, 'sender_phone', FILTER_DEFAULT);
$sender_phone = preg_replace('/[^+0-9]/', '', $sender_phone);
$return_locker_id = filter_input(INPUT_POST, 'return_locker_id', FILTER_DEFAULT);
$return_locker_id = strtoupper(preg_replace('/[^A-Z0-9]/i', '', $return_locker_id));

// --- NOWOŚĆ: Pobierz wybrany rozmiar paczki ---
$parcel_size = filter_input(INPUT_POST, 'parcel_size', FILTER_DEFAULT); // Powinno być 'medium' lub 'large'

// Sprawdź, czy wszystkie wymagane pola są poprawne
if (!$form_id || $amount_from_form === false || !$service_name || !$sender_name || !$sender_email || empty($sender_phone) || empty($return_locker_id) || !in_array($parcel_size, ['medium', 'large'])) { // Dodano walidację parcel_size
    $_SESSION['error_message'] = "Nieprawidłowe lub brakujące dane w formularzu. Proszę wypełnić wszystkie pola poprawnie.";
    try {
        $stmt_uuid = $pdo->prepare("SELECT uuid FROM forms WHERE id = ?"); $stmt_uuid->execute([$form_id ?? 0]);
        $form_uuid_redirect = $stmt_uuid->fetchColumn();
        if ($form_uuid_redirect) { header("Location: form.php?uuid=" . $form_uuid_redirect); } else { header("Location: index.php"); }
    } catch (\PDOException $e) { error_log(/*...*/); header("Location: index.php"); }
    exit;
}

// 2. Weryfikacja ceny z bazą danych (ZMIENIONA LOGIKA)
try {
    $stmt_form_check = $pdo->prepare("SELECT price, uuid FROM forms WHERE id = ? AND is_active = TRUE");
    $stmt_form_check->execute([$form_id]);
    $form_data = $stmt_form_check->fetch();

    if (!$form_data) { throw new Exception("Formularz nie istnieje lub nieaktywny."); }

    $db_price = (float)$form_data['price']; // Cena bazowa
    $form_uuid = $form_data['uuid'];

    // --- NOWA LOGIKA WERYFIKACJI CENY ---
    // Pobierz dopłatę z bazy
    $large_parcel_surcharge_str = get_setting('large_parcel_surcharge', $pdo);
    $large_parcel_surcharge = ($large_parcel_surcharge_str !== null) ? (float)$large_parcel_surcharge_str : 5.00;

    // Oblicz oczekiwaną cenę końcową na serwerze
    $expected_final_price = $db_price;
    if ($parcel_size === 'large') {
        $expected_final_price += $large_parcel_surcharge;
    }
    $expected_final_price = round($expected_final_price, 2); // Zaokrąglij do 2 miejsc po przecinku

    // Porównaj cenę z formularza (otrzymaną) z ceną oczekiwaną
    if (abs($expected_final_price - $amount_from_form) > 0.01) { // Tolerancja 1 grosza
         log_message("Błąd niezgodności ceny! Oczekiwano (z bazy): {$expected_final_price}, Otrzymano (z formularza): {$amount_from_form}");
        throw new Exception("Niezgodność ceny przesłanej z formularza z ceną obliczoną na serwerze.");
    }
    
    // Użyj zweryfikowanej ceny (w groszach)
    $amount_grosze = (int) round($expected_final_price * 100);
    // ===================================

} catch (\PDOException | \Exception $e) {
    error_log("Błąd weryfikacji formularza/ceny (form_id: {$form_id}): " . $e->getMessage());
    $_SESSION['error_message'] = "Wystąpił błąd podczas weryfikacji danych formularza. Spróbuj ponownie.";
    if (isset($form_uuid)) { header("Location: form.php?uuid=" . $form_uuid); }
    else { header("Location: index.php"); }
    exit;
}

// 3. Generowanie Session ID i zapis zamówienia do bazy danych
$session_id = 'ORD-' . strtoupper(bin2hex(random_bytes(8)));

try {
    // --- ZMIANA: Dodaj $parcel_size do zapytania INSERT ---
    $stmt_insert = $pdo->prepare(
        "INSERT INTO orders (form_id, session_id, sender_name, sender_email, sender_phone, return_locker_id, parcel_size, amount, currency, payment_status, repair_status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PLN', 'pending', 'new', NOW(), NOW())"
    );
    $stmt_insert->execute([
        $form_id, $session_id, $sender_name, $sender_email, $sender_phone, $return_locker_id,
        $parcel_size, // Zapisz wybrany rozmiar paczki
        $expected_final_price // Zapisz zweryfikowaną cenę końcową
    ]);
    // ==================================================
} catch (\PDOException $e) {
    if ($e->getCode() == 23000) { $_SESSION['error_message'] = "Błąd ID sesji. Spróbuj ponownie."; }
    else { $_SESSION['error_message'] = "Błąd serwera podczas zapisu zamówienia."; }
    error_log("DB Error inserting order: " . $e->getMessage());
    header("Location: form.php?uuid=" . $form_uuid);
    exit;
}

// 4. Pobranie *aktywnej* konfiguracji P24 z bazy
$p24_posId = get_active_setting('p24_pos_id', $pdo);
$p24_crcKey = get_active_setting('p24_crc_key', $pdo);
$p24_apiKey = get_active_setting('p24_api_key', $pdo);
$p24_sandbox_enabled = get_setting('p24_sandbox_enabled', $pdo);

log_message("Odczytano ustawienia P24 dla p24_process.php: ..."); // Logi jak poprzednio

$p24_apiUrlBase = $p24_sandbox_enabled ? "https://sandbox.przelewy24.pl/api/v1" : "https://secure.przelewy24.pl/api/v1";
$p24_redirectBase = $p24_sandbox_enabled ? "https://sandbox.przelewy24.pl/trnRequest/" : "https://secure.przelewy24.pl/trnRequest/";
$p24_registerUrl = $p24_apiUrlBase . '/transaction/register';

log_message(" - Używany URL API P24 do rejestracji: " . $p24_registerUrl);

if (!$p24_posId || !$p24_crcKey || !$p24_apiKey) {
    $mode = $p24_sandbox_enabled ? 'sandbox' : 'production';
    error_log("Krytyczny błąd: Brak aktywnych kluczy API Przelewy24 ({$mode}) w bazie danych.");
    $_SESSION['error_message'] = "Błąd konfiguracji systemu płatności ({$mode}). Skontaktuj się z administratorem.";
    header("Location: form.php?uuid=" . $form_uuid);
    exit;
}

$appBaseUrl = "https://butolog.pl/zamowienie";
$urlReturn = $appBaseUrl . '/p24_return.php';
$urlStatus = $appBaseUrl . '/p24_status.php';

// 5. Przygotowanie danych i podpisu ('sign') dla Przelewy24 API
$signData = [
    "sessionId" => $session_id,
    "merchantId" => (int)$p24_posId,
    "amount" => $amount_grosze, // Użyj $amount_grosze (obliczonej z $expected_final_price)
    "currency" => "PLN",
    "crc" => $p24_crcKey
];

$sign = hash('sha384', json_encode($signData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

$requestPayload = [
    "merchantId" => (int)$p24_posId,
    "posId" => (int)$p24_posId,
    "sessionId" => $session_id,
    "amount" => $amount_grosze, // Użyj $amount_grosze
    "currency" => "PLN",
    "description" => $service_name . " (Zam: " . $session_id . ")",
    "email" => $sender_email,
    "client" => $sender_name,
    "country" => "PL",
    "language" => "pl",
    "urlReturn" => $urlReturn,
    "urlStatus" => $urlStatus,
    "sign" => $sign
];

// 6. Wywołanie API Przelewy24
log_message("P24 Register Request for sessionId {$session_id} (Mode: " . ($p24_sandbox_enabled ? 'Sandbox' : 'Production') . "): " . json_encode($requestPayload));
$p24Result = call_p24_api($p24_registerUrl, $p24_posId, $p24_apiKey, $requestPayload, 'POST');
log_message("P24 Register Response for sessionId {$session_id} (HTTP {$p24Result['http_code']}): " . $p24Result['response']);

// 7. Przetworzenie odpowiedzi z P24
if ($p24Result['http_code'] == 200 && isset($p24Result['data']['data']['token'])) {
    $token = $p24Result['data']['data']['token'];
    $paymentLink = $p24_redirectBase . $token;
    log_message("P24 registration successful for sessionId {$session_id}. Token: {$token}. Redirecting to: {$paymentLink}");
    header("Location: " . $paymentLink);
    exit;
} else {
    // Obsługa błędu P24
    $errorDetails = $p24Result['response'] ?? 'Brak odpowiedzi P24.';
    if(isset($p24Result['data']['error'])) { $errorDetails = "P24 Error: " . ($p24Result['data']['error'] ?? 'Unknown') . " (Code: " . ($p24Result['data']['code'] ?? 'N/A') . ")"; }
    elseif(isset($p24Result['data']['errors'])) { $errorDetails = "P24 Validation Errors: " . json_encode($p24Result['data']['errors']); }
    elseif ($p24Result['http_code'] === 0) { $errorDetails = "Błąd połączenia z serwerem Przelewy24."; }
    error_log("P24 Register Error for sessionId {$session_id} (HTTP {$p24Result['http_code']}): " . $errorDetails);
    try { $pdo->prepare("UPDATE orders SET payment_status = 'cancelled', updated_at = NOW() WHERE session_id = ?")->execute([$session_id]); }
    catch (\PDOException $e) { error_log("DB Error updating order to cancelled for {$session_id}: " . $e->getMessage()); }
    $_SESSION['error_message'] = "Nie udało się rozpocząć procesu płatności. Szczegóły: " . htmlspecialchars($errorDetails);
    header("Location: form.php?uuid=" . $form_uuid);
    exit;
}

?>