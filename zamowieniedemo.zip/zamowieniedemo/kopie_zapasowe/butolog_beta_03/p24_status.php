<?php
// /zamowienie/p24_status.php

// Ignoruj przerwanie połączenia przez klienta (P24), kontynuuj działanie skryptu
ignore_user_abort(true);
// Ustaw odpowiednio długi czas wykonywania skryptu
set_time_limit(120); // 2 minuty

require_once 'includes/db.php'; // Połączenie z bazą i funkcja get_setting()
require_once 'includes/functions.php'; // Funkcje pomocnicze

// --- Pobranie *aktywnej* konfiguracji z bazy danych ---
$p24_posId = get_active_setting('p24_pos_id', $pdo);
$p24_crcKey = get_active_setting('p24_crc_key', $pdo);
$p24_apiKey = get_active_setting('p24_api_key', $pdo);
$p24_sandbox_enabled = get_setting('p24_sandbox_enabled', $pdo);
$p24_apiUrlBase = $p24_sandbox_enabled ? "https://sandbox.przelewy24.pl/api/v1" : "https://secure.przelewy24.pl/api/v1";
$p24_verifyUrl = $p24_apiUrlBase . '/transaction/verify';

$inpost_org_id = get_active_setting('inpost_org_id', $pdo);
// --- TWÓJ TOKEN WSTAWIONY PONIŻEJ ---
$inpost_token = "eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJkVzROZW9TeXk0OHpCOHg4emdZX2t5dFNiWHY3blZ0eFVGVFpzWV9TUFA4In0.eyJleHAiOjIwNTc5NTk5MTcsImlhdCI6MTc0MjU5OTkxNywianRpIjoiOGZjMWZiNmQtNTJkOS00ZDNkLTkxZWQtNTA1YTU3MGNmODA3IiwiaXNzIjoiaHR0cHM6Ly9zYW5kYm94LWxvZ2luLmlucG9zdC5wbC9hdXRoL3JlYWxtcy9leHRlcm5hbCIsInN1YiI6ImY6N2ZiZjQxYmEtYTEzZC00MGQzLTk1ZjYtOThhMmIxYmFlNjdiOjR2UlJaSDZHNW1LUWdTa2FQXy0yWFVKd19pT0hvTUIwMDF1aGE4SE5aVzAiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJzaGlweCIsInNlc3Npb25fc3RhdGUiOiI0NzI1NjUwMi04NjIzLTQ2YmUtOTRmOC02NTA0YzZmNjk2MTMiLCJzY29wZSI6Im9wZW5pZCBhcGk6YXBpcG9pbnRzIGFwaTpzaGlweCIsInNpZCI6IjQ3MjU2NTAyLTg2MjMtNDZiZS05NGY4LTY1MDRjNmY2OTYxMyIsImFsbG93ZWRfcmVmZXJyZXJzIjoiIiwidXVpZCI6IjMxNzAwYmU3LTA2ZTAtNGVkZC05NTA1LTAzZjJhZjQ3M2QwMiIsImVtYWlsIjoia29udGFrdEBwaWNhYmVsYS5wbCJ9.gi0k1iTptAMC0iAILF9hfU5QsM3xClD59XcAs4Dax7FfGmoQTBlnsirBRO6bdVsAEaAN7eXB6kVzIc2om5bFocK8Xtk_z5ih9Piu-PmLKFp9FABmO1KUbq6ZprKBgZvHGEv01IIAgUvqKWfs_PldlCwwj9pBSjgp5IlGHiO0_xRX0kQiAd6RfIWLYuUi_zjTVltv1jS0eJ_eVmA2TOzxb2UF7mZrEpsIcoWbi_yba9g2GgJ46VxrRDI998TgBENPpMLFOECoG_-y60PF2nSU9Bl92qu0e6knxs_DxNYk_dScM0KKT842MorbniHGXcN-V8AfZzgvV1pxDLeqpb1IGA";
$inpost_sandbox_enabled = get_setting('inpost_sandbox_enabled', $pdo);
$inpost_apiUrlBase = $inpost_sandbox_enabled ? "https://sandbox-api-shipx-pl.easypack24.net/v1" : "https://api-shipx-pl.easypack24.net/v1";
$inpost_createShipmentUrl = $inpost_apiUrlBase . "/organizations/{$inpost_org_id}/shipments";
$inpost_getShipmentBaseUrl = $inpost_apiUrlBase . "/shipments/";

// Ustawienia odbiorcy i email
$receiver_name = get_setting('service_receiver_name', $pdo);
$receiver_email = get_setting('service_receiver_email', $pdo);
$receiver_phone = get_setting('service_receiver_phone', $pdo);
$receiver_locker = get_setting('service_receiver_locker', $pdo);
$sender_name_override = get_setting('sender_name_override', $pdo);
$email_from_address = get_setting('email_from_address', $pdo);
$email_from_name = get_setting('email_from_name', $pdo);

// Sprawdzenie kluczowych ustawień
$p24_mode_text = $p24_sandbox_enabled ? 'sandbox' : 'production';
$inpost_mode_text = $inpost_sandbox_enabled ? 'sandbox' : 'production';
if (!$p24_posId || !$p24_crcKey || !$p24_apiKey || !$inpost_org_id || !$inpost_token || !$receiver_locker || !$email_from_address || !$email_from_name) {
    log_message("KRYTYCZNY BŁĄD w p24_status.php: Brak kluczowych aktywnych ustawień (P24: {$p24_mode_text}, InPost: {$inpost_mode_text}). Sprawdź tabelę settings.");
    http_response_code(500); exit("Internal Server Configuration Error");
}

// === KROK 1: Odbierz powiadomienie P24 ===
log_message("--- Nowe powiadomienie P24 [p24_status.php] ---");
$jsonInput = file_get_contents('php://input');
log_message("Odebrano dane P24: " . $jsonInput);
$p24WebhookData = json_decode($jsonInput, true);
if (!$p24WebhookData || !isset($p24WebhookData['orderId']) || !isset($p24WebhookData['sessionId']) || !isset($p24WebhookData['amount']) || !isset($p24WebhookData['currency'])) {
    log_message("Błąd P24 Webhook: Nieprawidłowe dane JSON lub brak kluczowych pól.");
    http_response_code(400); exit("Invalid Webhook Data");
}
$session_id = $p24WebhookData['sessionId'];

// === KROK 1.5: Sprawdź zamówienie w bazie ===
try {
    $stmt_check = $pdo->prepare("SELECT id, payment_status, repair_status, sender_name, sender_email, sender_phone, return_locker_id, inpost_shipment_id, inpost_tracking_number, parcel_size, amount FROM orders WHERE session_id = ?");
    $stmt_check->execute([$session_id]);
    $order = $stmt_check->fetch();
    if (!$order) {
        log_message("Błąd: Nie znaleziono zamówienia w bazie danych dla sessionId: " . $session_id);
        http_response_code(404); exit("Order Not Found");
    }
    if ($order['payment_status'] == 'paid' && $order['repair_status'] == 'label_generated') {
         log_message("Informacja: Otrzymano powtórne powiadomienie dla już przetworzonego zamówienia sessionId: " . $session_id);
         http_response_code(200); exit("OK - Already Processed");
    }
} catch (\PDOException $e) {
    error_log("DB Error checking order (sessionId: {$session_id}): " . $e->getMessage());
    http_response_code(500); exit("Internal Server Error - DB Check");
}

// === KROK 2: Weryfikacja P24 ===
log_message("Rozpoczynanie weryfikacji P24 dla sessionId: " . $session_id . ", P24 OrderID: " . $p24WebhookData['orderId']);
$amount_for_verification_grosze = (int) round((float)$order['amount'] * 100);
if ($amount_for_verification_grosze !== (int)$p24WebhookData['amount']) {
    log_message("KRYTYCZNY BŁĄD: Niezgodność kwoty! Otrzymano z P24: {$p24WebhookData['amount']}, Oczekiwano (z bazy): {$amount_for_verification_grosze}. SessionId: {$session_id}");
    http_response_code(400); exit("Amount mismatch");
}
$verifySignData = [ "sessionId" => $session_id, "orderId" => (int)$p24WebhookData['orderId'], "amount" => $amount_for_verification_grosze, "currency" => $p24WebhookData['currency'], "crc" => $p24_crcKey ];
$verifySign = hash('sha384', json_encode($verifySignData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
$verifyPayload = [ "merchantId" => (int)$p24_posId, "posId" => (int)$p24_posId, "sessionId" => $session_id, "amount" => $amount_for_verification_grosze, "currency" => $p24WebhookData['currency'], "orderId" => (int)$p24WebhookData['orderId'], "sign" => $verifySign ];

log_message("Dane do podpisu weryfikacji: " . json_encode($verifySignData));
log_message("Wygenerowany podpis weryfikacji: " . $verifySign);
log_message("Pełny payload weryfikacji wysyłany do P24: " . json_encode($verifyPayload));
log_message("Klucze używane do autoryzacji weryfikacji: User=[" . $p24_posId . "] Key=[" . substr($p24_apiKey, 0, 5) . "...]");

$p24VerifyResult = call_p24_api($p24_verifyUrl, $p24_posId, $p24_apiKey, $verifyPayload, 'PUT');
log_message("Odpowiedź weryfikacji P24 (HTTP {$p24VerifyResult['http_code']}): " . $p24VerifyResult['response']);

// === KROK 3: Płatność zweryfikowana - InPost i Email ===
if ($p24VerifyResult['http_code'] == 200 && isset($p24VerifyResult['data']['data']['status']) && $p24VerifyResult['data']['data']['status'] == 'success') {
    log_message("Weryfikacja P24 Pomyślna dla sessionId: {$session_id}");

    $updatedRows = 0;
    if ($order['payment_status'] == 'pending') {
        try {
            $stmt_update_paid = $pdo->prepare("UPDATE orders SET payment_status = 'paid', p24_order_id = ?, updated_at = NOW() WHERE session_id = ? AND payment_status = 'pending'");
            $updatedRows = $stmt_update_paid->execute([$p24WebhookData['orderId'], $session_id]) ? $stmt_update_paid->rowCount() : 0;
            if ($updatedRows > 0) {
                 log_message("Zaktualizowano status zamówienia {$session_id} na 'paid'.");
                 $order['payment_status'] = 'paid';
            } else {
                 log_message("OSTRZEŻENIE: Weryfikacja P24 pomyślna, ale nie zaktualizowano statusu 'pending' na 'paid' dla sessionId: {$session_id}.");
            }
        } catch (\PDOException $e) {
            error_log("DB Error updating order to paid for {$session_id}: " . $e->getMessage());
        }
    } else {
        log_message("Informacja: Zamówienie {$session_id} miało już status {$order['payment_status']}.");
    }

    $existing_shipment_id = $order['inpost_shipment_id'];

    if ($existing_shipment_id && $order['repair_status'] == 'label_generated') {
        log_message("Informacja: Etykieta InPost dla sessionId {$session_id} już istnieje (ID: {$existing_shipment_id}).");
         if ($order['repair_status'] == 'new') {
            log_message("Status naprawy to 'new', ponowne wysyłanie e-maila z etykietą.");
            $trackingNumber = $order['inpost_tracking_number'] ?? 'Brak danych';
            $shipmentId = $existing_shipment_id;
            $labelDownloadPageLink = "https://butolog.pl/zamowienie/download_page.php?shipment_id=" . $shipmentId;
            $customerEmail = $order['sender_email']; $customerName = $order['sender_name']; $returnLockerId = $order['return_locker_id'];
            $amountPaid = number_format($p24WebhookData['amount'] / 100, 2, ',', ''); $currency = $p24WebhookData['currency'];
            $targetLocker = $receiver_locker;
            $subject = "[Ponowne wysłanie] Potwierdzenie opłaty i etykieta nadawcza {$email_from_name} (Zam: {$sessionId})";
            $message = "Witaj {$customerName},\n\n"
                     . "Dziękujemy za opłacenie usługi naprawy obuwia (Zamówienie: {$sessionId}) w {$email_from_name}.\n\n"
                     . "Status płatności: OPŁACONE\n"
                     . "Kwota: {$amountPaid} {$currency}\n\n"
                     . "--- ETYKIETA NADAWCZA INPOST ---\n\n"
                     . "Wygenerowaliśmy dla Ciebie etykietę, abyś mógł wysłać do nas swoje buty.\n\n"
                     . "**Strona do pobrania etykiety (PDF):**\n"
                     . $labelDownloadPageLink . "\n\n"
                     . "**Numer przesyłki (śledzenia) do nas:** {$trackingNumber}\n\n"
                     . "Prosimy o wydrukowanie etykiety, naklejenie jej na paczkę i nadanie w dowolnym paczomacie lub PaczkoPunkcie. Została ona zaadresowana do naszego paczkomatu: {$targetLocker}.\n\n"
                     . "--- DANE ZWROTNE ---\n"
                     . "Po naprawie odeślemy buty do wskazanego przez Ciebie paczkomatu: {$returnLockerId}.\n\n"
                     . "Pozdrawiamy,\n"
                     . "Zespół {$email_from_name}";

             $headers = "From: {$email_from_name} <{$email_from_address}>\r\n"
                      . "Reply-To: {$email_from_address}\r\n"
                      . "Content-Type: text/plain; charset=UTF-8\r\n"
                      . "X-Mailer: PHP/" . phpversion();

             if (mail($customerEmail, $subject, $message, $headers)) { log_message("Pomyślnie wysłano ponownie e-mail..."); }
             else { log_message("BŁĄD: mail() nie powiodło się przy ponownym wysłaniu..."); }
             
             try {
                $pdo->prepare("UPDATE orders SET repair_status = 'label_generated', updated_at = NOW() WHERE session_id = ? AND repair_status = 'new'")->execute([$session_id]);
             } catch (\PDOException $e) { error_log("DB Error updating repair_status after resend for {$session_id}: " . $e->getMessage()); }
         }

    } else {
        // --- Generowanie Standardowej Etykiety InPost ---
        log_message("Rozpoczynanie generowania etykiety InPost dla sessionId: {$session_id}");

        if (empty($order['sender_email'])) {
             log_message("BŁĄD KRYTYCZNY: Brak danych klienta w zamówieniu {$session_id}.");
             try { $pdo->prepare("UPDATE orders SET repair_status = 'cancelled' WHERE session_id = ?")->execute([$session_id]); } catch (\PDOException $e) { error_log("DB Error: ".$e->getMessage()); }
             http_response_code(200); exit("OK - Missing Customer Data");
        }
        log_message("Pomyślnie pobrano dane klienta z bazy dla sessionId: {$session_id}");

        // 3.1. Przygotuj payload dla API InPost
        // Użyj nazwy klienta jako nadawcy (zgodnie z życzeniem)
        $sender_name_inpost = !empty($sender_name_override) ? $sender_name_override : $order['sender_name'];
        $sender_company_name_inpost = $sender_name_inpost; // Używamy tego samego dla obu pól

        // Odczytaj rozmiar paczki z bazy
        $parcel_template = ($order['parcel_size'] === 'large') ? 'large' : 'medium';
        log_message("Wybrany rozmiar paczki (z bazy): {$order['parcel_size']}, Używany szablon InPost: {$parcel_template}");

        $inpostPayload = [
            'receiver' => ['name' => $receiver_name, 'email' => $receiver_email, 'phone' => $receiver_phone],
            'sender' => [
                'name' => $sender_name_inpost,
                'company_name' => $sender_company_name_inpost,
                'email' => $order['sender_email'],
                'phone' => $order['sender_phone']
                // === POPRAWKA: Usunięto blok 'address' ===
            ],
            'parcels' => [['template' => $parcel_template]], // Użyj $parcel_template
            'service' => 'inpost_locker_standard',
            'reference' => $session_id,
            'comments' => 'Naprawa obuwia (Zam: ' . $session_id . ')',
            'additional_services' => [], // Upewnij się, że 'labelless' jest usunięte
            'sending_method' => 'any_point', // Ustawienie 'any_point'
            'custom_attributes' => [
                'target_point' => $receiver_locker,
                'sending_method' => 'any_point' // Powtórzenie w custom_attributes
            ]
        ];
        log_message("Wysyłanie żądania utworzenia przesyłki InPost (standard): " . json_encode($inpostPayload));

        // 3.2. Wywołaj API InPost
        $inpostCreateResult = call_inpost_api_post($inpost_createShipmentUrl, $inpost_token, $inpostPayload);
        log_message("Odpowiedź InPost (tworzenie standard) (HTTP {$inpostCreateResult['http_code']}): " . $inpostCreateResult['response']);
        $inpostCreateResponse = $inpostCreateResult['data'];

        // 3.3. Przetwórz odpowiedź InPost i wyślij e-mail
        if ($inpostCreateResult['http_code'] == 201 && isset($inpostCreateResponse['id'])) {
            $shipmentId = $inpostCreateResponse['id'];
            $trackingNumber = $inpostCreateResponse['tracking_number'] ?? null;
            $targetLocker = $inpostCreateResponse['custom_attributes']['target_point'] ?? ($inpostCreateResponse['target_point'] ?? $receiver_locker);
            
            // === POPRAWKA POBIERANIA NUMERU ŚLEDZENIA ===
            // Sprawdź też w 'parcels', jeśli na głównym poziomie jest null
            if (empty($trackingNumber) && isset($inpostCreateResponse['parcels'][0]['tracking_number'])) {
                $trackingNumber = $inpostCreateResponse['parcels'][0]['tracking_number'];
                log_message("Pobrano numer śledzenia (z 'parcels'): {$trackingNumber}");
            }
            // ===========================================

            log_message("Sukces InPost! Utworzono przesyłkę standard. ID: {$shipmentId}, Tracking: {$trackingNumber}, Paczkomat: {$targetLocker}");

            // Ponowne pobranie numeru śledzenia (jeśli nadal pusty)
            if (empty($trackingNumber)) {
                log_message("Numer śledzenia pusty/null. Czekam 5 sekund...");
                sleep(5);
                $inpostGetShipmentUrl = $inpost_getShipmentBaseUrl . $shipmentId;
                $inpostGetResult = call_inpost_api_get($inpostGetShipmentUrl, $inpost_token);
                log_message("Odpowiedź InPost (GET /shipments/{$shipmentId}): (HTTP {$inpostGetResult['http_code']}): " . $inpostGetResult['response']);
                if ($inpostGetResult['http_code'] == 200 && isset($inpostGetResult['data'])) {
                    // Sprawdź oba miejsca w odpowiedzi GET
                    $trackingNumber = $inpostGetResult['data']['tracking_number'] ?? ($inpostGetResult['data']['parcels'][0]['tracking_number'] ?? 'Oczekuje na nadanie');
                    log_message("Pobrano zaktualizowany numer śledzenia: {$trackingNumber}");
                } else {
                    log_message("Nie udało się pobrać numeru śledzenia.");
                    $trackingNumber = 'Oczekuje na nadanie';
                }
            }

            // Aktualizacja zamówienia w bazie
            $trackingNumberForDb = ($trackingNumber == 'Oczekuje na nadanie' || empty($trackingNumber)) ? null : $trackingNumber;
            try {
                $stmt_update_inpost = $pdo->prepare("UPDATE orders SET inpost_shipment_id = ?, inpost_tracking_number = ?, repair_status = 'label_generated', updated_at = NOW() WHERE session_id = ?");
                $stmt_update_inpost->execute([$shipmentId, $trackingNumberForDb, $session_id]);
                 log_message("Zaktualizowano zamówienie {$session_id} o dane InPost.");
            } catch (\PDOException $e) { error_log("DB Error updating order with InPost data for {$session_id}: " . $e->getMessage()); }

            // Wyślij e-mail do klienta (z linkiem do etykiety)
            $labelDownloadPageLink = "https://butolog.pl/zamowienie/download_page.php?shipment_id=" . $shipmentId;
            $customerEmail = $order['sender_email'];
            $customerName = $order['sender_name'];
            $returnLockerId = $order['return_locker_id'];
            $amountPaid = number_format($p24WebhookData['amount'] / 100, 2, ',', '');
            $currency = $p24WebhookData['currency'];

            $subject = "Potwierdzenie opłaty i etykieta nadawcza {$email_from_name} (Zam: {$sessionId})";
            $message = "Witaj {$customerName},\n\n"
                     . "Dziękujemy za opłacenie usługi naprawy obuwia (Zamówienie: {$sessionId}) w {$email_from_name}.\n\n"
                     . "Status płatności: OPŁACONE\n"
                     . "Kwota: {$amountPaid} {$currency}\n\n"
                     . "--- ETYKIETA NADAWCZA INPOST ---\n\n"
                     . "Wygenerowaliśmy dla Ciebie etykietę, abyś mógł wysłać do nas swoje buty.\n\n"
                     . "**Strona do pobrania etykiety (PDF):**\n"
                     . $labelDownloadPageLink . "\n\n"
                     . "**Numer przesyłki (śledzenia) do nas:** {$trackingNumber}\n\n"
                     . "Prosimy o wydrukowanie etykiety, naklejenie jej na paczkę i nadanie w dowolnym paczomacie lub PaczkoPunkcie. Została ona zaadresowana do naszego paczkomatu: {$targetLocker}.\n\n"
                     . "--- DANE ZWROTNE ---\n"
                     . "Po naprawie odeślemy buty do wskazanego przez Ciebie paczkomatu: {$returnLockerId}.\n\n"
                     . "Pozdrawiamy,\n"
                     . "Zespół {$email_from_name}";

            $headers = "From: {$email_from_name} <{$email_from_address}>\r\n"
                     . "Reply-To: {$email_from_address}\r\n"
                     . "Content-Type: text/plain; charset=UTF-8\r\n"
                     . "X-Mailer: PHP/" . phpversion();

            if (mail($customerEmail, $subject, $message, $headers)) {
                log_message("Pomyślnie wysłano e-mail z etykietą dla sessionId: {$session_id} na adres: " . $customerEmail);
            } else {
                log_message("BŁĄD: mail() nie powiodło się dla sessionId: {$session_id} (standard).");
                error_log("PHP Mail Error: Failed to send email to {$customerEmail} for session {$session_id}");
            }

        } else {
            // Obsługa błędu InPost
            $errorResponse = $inpostCreateResult['response'] ?? 'Brak odpowiedzi InPost';
            log_message("BŁĄD KRYTYCZNY INPOST dla sessionId: {$session_id}. Nie udało się wygenerować etykiety standard. Odpowiedź (HTTP {$inpostCreateResult['http_code']}): " . $errorResponse);
            try {
                $stmt_update_error = $pdo->prepare("UPDATE orders SET repair_status = 'cancelled', payment_status = 'paid', updated_at = NOW() WHERE session_id = ?");
                $stmt_update_error->execute([$session_id]);
                 log_message("Zaktualizowano status zamówienia {$session_id} na 'cancelled' po błędzie InPost.");
            } catch (\PDOException $e) { error_log("DB Error updating order status to cancelled for {$session_id}: " . $e->getMessage()); }
        }
    } // Koniec bloku 'if (!$existing_shipment_id)'

} else {
    // Obsługa błędu weryfikacji P24
    $errorResponseP24 = $p24VerifyResult['response'] ?? 'Brak odpowiedzi P24';
    log_message("Błąd weryfikacji P24 dla sessionId: {$session_id}. Odpowiedź P24 (HTTP {$p24VerifyResult['http_code']}): " . $errorResponseP24);
    try {
         $stmt_update_failed = $pdo->prepare("UPDATE orders SET payment_status = 'failed', updated_at = NOW() WHERE session_id = ? AND payment_status = 'pending'");
         $updatedRowsFailed = $stmt_update_failed->execute([$session_id]);
          if ($updatedRowsFailed > 0) {
              log_message("Zaktualizowano status zamówienia {$session_id} na 'failed'.");
          }
    } catch (\PDOException $e) {
         error_log("DB Error updating order status to failed for {$session_id}: " . $e->getMessage());
    }
}

// === KROK 4: Zawsze odpowiedz P24 kodem 200 OK ===
http_response_code(200);
echo "OK";
exit;

?>