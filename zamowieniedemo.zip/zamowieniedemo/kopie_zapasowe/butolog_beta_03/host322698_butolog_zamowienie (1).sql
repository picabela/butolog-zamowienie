-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Paź 28, 2025 at 02:18 PM
-- Wersja serwera: 10.11.14-MariaDB-cll-lve
-- Wersja PHP: 8.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `host322698_butolog_zamowienie`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `admins`
--

INSERT INTO `admins` (`id`, `username`, `password_hash`, `created_at`) VALUES
(1, 'admin', '$2y$10$DJArxgfVyQHXekrbMOGiPe1OotnCrNPKq7/aW1E2xyY7rZ6.qUnkS', '2025-10-24 15:51:51');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `forms`
--

CREATE TABLE `forms` (
  `id` int(11) NOT NULL,
  `uuid` varchar(36) NOT NULL,
  `service_name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `forms`
--

INSERT INTO `forms` (`id`, `uuid`, `service_name`, `price`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'test-form-uuid-123', 'Standardowa Naprawa Obuwia', 59.99, 'Podstawowa usługa naprawy.', 1, '2025-10-24 16:10:27', '2025-10-24 16:10:27'),
(2, '05aaeb9c-d269-4e0b-a1d8-3f3c93417d3c', 'FLeki', 32.00, '', 1, '2025-10-24 17:31:08', '2025-10-24 17:31:08'),
(3, 'aaaaa-sssss-sdsdsdsd', 'Naprawa obuwia', 29.00, '', 1, '2025-10-24 18:12:13', '2025-10-24 18:12:13'),
(4, 'qqq-wqwq', 'szycie butów', 22.00, '', 1, '2025-10-24 18:33:21', '2025-10-24 18:33:21'),
(5, '222-121', 'obcasy', 23.00, '', 1, '2025-10-24 19:37:04', '2025-10-24 19:37:04'),
(6, '30aadda2-6f4d-40eb-87b2-e63e47975ab2', 'fleki', 11.00, '', 1, '2025-10-24 20:02:27', '2025-10-24 20:02:27'),
(7, 'nnnn2nnnnn2', 'Naprawa butów', 100.00, '', 1, '2025-10-24 20:39:45', '2025-10-24 20:39:45'),
(8, 'iiiiiiiddddddd', 'Naprawa butów damskich', 99.00, '', 1, '2025-10-24 20:47:45', '2025-10-24 20:47:45');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `session_id` varchar(50) NOT NULL,
  `p24_order_id` bigint(20) DEFAULT NULL,
  `inpost_shipment_id` varchar(50) DEFAULT NULL,
  `inpost_tracking_number` varchar(50) DEFAULT NULL,
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(20) NOT NULL,
  `return_locker_id` varchar(50) NOT NULL,
  `parcel_size` enum('medium','large') NOT NULL DEFAULT 'medium',
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'PLN',
  `payment_status` enum('pending','paid','failed','cancelled') DEFAULT 'pending',
  `repair_status` enum('new','label_generated','shipped_to_service','in_repair','repair_done','shipped_back','completed','cancelled') DEFAULT 'new',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `orders`
--

INSERT INTO `orders` (`id`, `form_id`, `session_id`, `p24_order_id`, `inpost_shipment_id`, `inpost_tracking_number`, `sender_name`, `sender_email`, `sender_phone`, `return_locker_id`, `parcel_size`, `amount`, `currency`, `payment_status`, `repair_status`, `created_at`, `updated_at`) VALUES
(1, 1, 'ORD-740C3040D4EBE570', NULL, NULL, NULL, 'Patryk Holewski Holewski', 'zapleczowe@o2.pl', '612345678', 'KRA010', 'medium', 59.99, 'PLN', 'cancelled', 'new', '2025-10-24 16:14:50', '2025-10-24 16:14:51'),
(2, 1, 'ORD-0561232CB689D953', NULL, NULL, NULL, 'Patryk Holewski Holewski', 'zapleczowe@o2.pl', '612345678', 'KRA010', 'medium', 59.99, 'PLN', 'pending', 'new', '2025-10-24 16:16:12', '2025-10-24 16:16:12'),
(3, 1, 'ORD-AC356238D530FD14', 4300881484, '13629059', '600503307530552022223317', 'Patryk Holewski Holewski', 'zapleczowe@o2.pl', '612345678', 'KRA010', 'medium', 59.99, 'PLN', 'paid', 'label_generated', '2025-10-24 16:17:53', '2025-10-24 16:21:06'),
(4, 1, 'ORD-D6D245E43C30EEA1', 4300881488, '13629060', '600503307530552029728380', 'Patryk Holewski Holewski', 'kontakt@damianek.pl', '612345678', 'KRA010', 'medium', 59.99, 'PLN', 'paid', 'label_generated', '2025-10-24 16:20:55', '2025-10-24 16:21:07'),
(5, 3, 'ORD-E1A332A949785AC5', NULL, NULL, NULL, 'Marian Dupa', 'wojciech@picabela.pl', '000000909', 'KRA010', 'medium', 29.00, 'PLN', 'cancelled', 'new', '2025-10-24 18:13:13', '2025-10-24 18:13:13'),
(6, 3, 'ORD-6A4E5C10FC65A7C6', NULL, NULL, NULL, 'Marian Dupa', 'wojciech@picabela.pl', '888888888', 'KRA010', 'medium', 29.00, 'PLN', 'cancelled', 'new', '2025-10-24 18:17:15', '2025-10-24 18:17:15'),
(7, 2, 'ORD-190064CA71C4D4D7', NULL, NULL, NULL, 'Jan Testowy', 'wojciech@picabela.pl', '000000909', 'KRA010', 'medium', 32.00, 'PLN', 'cancelled', 'new', '2025-10-24 18:18:51', '2025-10-24 18:18:51'),
(8, 3, 'ORD-A2C6B101CC986A2B', NULL, NULL, NULL, 'Marian Dupa', 'wojciech@picabela.pl', '999999999', 'KRA010', 'medium', 29.00, 'PLN', 'cancelled', 'new', '2025-10-24 18:29:17', '2025-10-24 18:29:17'),
(9, 2, 'ORD-834DB67030E55DB3', NULL, NULL, NULL, 'Marian Dupa', 'wojciech@picabela.pl', '000000909', 'KRA010', 'medium', 32.00, 'PLN', 'cancelled', 'new', '2025-10-24 18:29:43', '2025-10-24 18:29:44'),
(10, 4, 'ORD-36024496EF03FF1E', NULL, NULL, NULL, 'Marian Dupa', 'wojciech@picabela.pl', '000000909', 'KRA010', 'medium', 22.00, 'PLN', 'cancelled', 'new', '2025-10-24 18:33:45', '2025-10-24 18:33:45'),
(11, 1, 'ORD-8BFCBA74DDDA6E85', NULL, NULL, NULL, 'Jak Mal', 'wojciech@picabela.pl', '222222222', 'KRA010', 'medium', 59.99, 'PLN', 'pending', 'new', '2025-10-24 18:37:02', '2025-10-24 18:37:02'),
(12, 4, 'ORD-B6582BAAC248D464', NULL, NULL, NULL, 'Jan Testowy', 'wojciech@picabela.pl', '999999999', 'KRA010', 'medium', 22.00, 'PLN', 'cancelled', 'new', '2025-10-24 18:40:37', '2025-10-24 18:40:37'),
(13, 1, 'ORD-4B5710815E875968', NULL, NULL, NULL, 'Waldek Kiepski', 'mck@picabela.pl', '600600600', 'KRA010', 'medium', 59.99, 'PLN', 'cancelled', 'new', '2025-10-24 18:44:46', '2025-10-24 18:44:46'),
(14, 1, 'ORD-E2E4237A8FAF6C13', NULL, NULL, NULL, 'Daniel Kto', 'kontakt@damianek.pl', '999999999', 'KRA010', 'medium', 59.99, 'PLN', 'cancelled', 'new', '2025-10-24 19:05:53', '2025-10-24 19:05:53'),
(15, 1, 'ORD-1BD00D1187B89D61', NULL, NULL, NULL, 'Jak Ko', 'kontakt@dmianek.pl', '222222222', 'KRA010', 'medium', 59.99, 'PLN', 'cancelled', 'new', '2025-10-24 19:08:52', '2025-10-24 19:08:52'),
(16, 2, 'ORD-7CE5CBB703753F9A', NULL, NULL, NULL, 'Jan Testowy', 'wojciech@picabela.pl', '222222222', 'KRA010', 'medium', 32.00, 'PLN', 'cancelled', 'new', '2025-10-24 19:19:53', '2025-10-24 19:19:53'),
(17, 1, 'ORD-4D383DC8B817DA45', NULL, NULL, NULL, 'Janek Ona', 'mck@picabela.pl', '111111111', 'KRA010', 'medium', 59.99, 'PLN', 'cancelled', 'new', '2025-10-24 19:26:36', '2025-10-24 19:26:36'),
(18, 4, 'ORD-B33A23145A9029CD', NULL, NULL, NULL, 'Jan Testowy', 'wojciech@picabela.pl', '000000909', 'KRA010', 'medium', 22.00, 'PLN', 'pending', 'new', '2025-10-24 19:36:22', '2025-10-24 19:36:22'),
(19, 5, 'ORD-DDB6D41FDE02A853', NULL, NULL, NULL, 'Maciek Jak', 'mck@picabela.pl', '111111111', 'KRA010', 'medium', 23.00, 'PLN', 'pending', 'new', '2025-10-24 19:37:31', '2025-10-24 19:37:31'),
(20, 5, 'ORD-F39EF0EFCA974B3A', NULL, NULL, NULL, 'Waldek Kiepski', 'wojciech@picabela.pl', '222222222', 'KRA010', 'medium', 23.00, 'PLN', 'pending', 'new', '2025-10-24 19:40:37', '2025-10-24 19:40:37'),
(21, 1, 'ORD-EBDC961A9233895D', NULL, NULL, NULL, 'Daniel Kto', 'mck@picabela.pl', '222222222', 'KRA010', 'medium', 59.99, 'PLN', 'pending', 'new', '2025-10-24 19:47:00', '2025-10-24 19:47:00'),
(22, 5, 'ORD-44C3411B0ECBC71A', 4300882508, NULL, NULL, 'Waldek Kiepski', 'wojciech@picabela.pl', '999999999', 'KRA010', 'medium', 23.00, 'PLN', 'paid', 'cancelled', '2025-10-24 19:59:00', '2025-10-24 20:52:08'),
(23, 6, 'ORD-2900F78C97B09723', NULL, NULL, NULL, 'Marek Jacek', 'kontakt@damianek.pl', '888888888', 'KRA010', 'medium', 11.00, 'PLN', 'pending', 'new', '2025-10-24 20:03:00', '2025-10-24 20:03:00'),
(24, 1, 'ORD-7195E9EDDF073DD6', NULL, NULL, NULL, 'Marek Jarek', 'mck@picabela.pl', '333333333', 'KRA010', 'medium', 59.99, 'PLN', 'pending', 'new', '2025-10-24 20:07:36', '2025-10-24 20:07:36'),
(25, 1, 'ORD-D7218143C00B69F1', 4300882553, '13629366', '600503307530552027456521', 'Marek Konrad', 'mck@picabela.pl', '222222222', 'KRA010', 'medium', 59.99, 'PLN', 'paid', 'label_generated', '2025-10-24 20:17:19', '2025-10-24 20:40:35'),
(26, 1, 'ORD-E1AC1A5A9F2B592D', NULL, NULL, NULL, 'Jan Testowy', 'mck@picabela.pl', '222222222', 'KRA010', 'medium', 59.99, 'PLN', 'pending', 'new', '2025-10-24 20:26:21', '2025-10-24 20:26:21'),
(27, 1, 'ORD-090099713DA37A00', 4300882594, '13629360', '600503307530552024941314', 'Marian Dupa', 'mck@picabela.pl', '222222222', 'KRA010', 'medium', 59.99, 'PLN', 'paid', 'label_generated', '2025-10-24 20:35:04', '2025-10-24 20:38:16'),
(28, 1, 'ORD-B61505C8AEB74323', 4300882612, '13629361', '600503307530552022446386', 'Janek Franek', 'mck@picabela.pl', '222222222', 'KRA010', 'medium', 59.99, 'PLN', 'paid', 'label_generated', '2025-10-24 20:38:31', '2025-10-24 20:38:45'),
(29, 7, 'ORD-DCB542DE68BCBBC8', 4300882617, '13629365', '600503307530552029951449', 'Waldek Kiepski', 'wojciech@picabela.pl', '333333333', 'KRA010', 'medium', 100.00, 'PLN', 'paid', 'label_generated', '2025-10-24 20:40:12', '2025-10-24 20:40:25'),
(30, 8, 'ORD-8F40B7F40AE69D9D', 4300882641, NULL, NULL, 'Piotr Ciuk', 'kontakt@damianek.pl', '999999999', 'KRA010', 'medium', 99.00, 'PLN', 'paid', 'cancelled', '2025-10-24 20:48:21', '2025-10-24 20:48:30'),
(31, 8, 'ORD-FD19009EFDDD110E', 4300882661, '13629383', '600503307530552029971728', 'Waldek Kiepski', 'mck@picabela.pl', '999999999', 'KRA010', 'medium', 99.00, 'PLN', 'paid', 'label_generated', '2025-10-24 20:55:04', '2025-10-24 20:55:16'),
(32, 8, 'ORD-B01F76E253D9371A', 4300882683, '13629397', '600503307531612022486944', 'Marek Jarek', 'mck@picabela.pl', '999999999', 'KRA010', 'medium', 99.00, 'PLN', 'paid', 'label_generated', '2025-10-24 21:04:06', '2025-10-24 21:04:18'),
(33, 1, 'ORD-4FD4765CAAB43A8A', 4300886964, NULL, NULL, 'Jan plaski ', 'Klocloslaw@gmail.com', '000000000', 'KRA010', 'medium', 59.99, 'PLN', 'paid', 'cancelled', '2025-10-26 21:06:04', '2025-10-26 21:06:26'),
(34, 2, 'ORD-8009CDA75BC538DA', 4300886992, '13631986', '600503107531612027374794', 'Piotr Nowakowski', 'Kontakt@damianek.pl', '666666366', 'KRA010', 'medium', 32.00, 'PLN', 'paid', 'label_generated', '2025-10-26 21:18:19', '2025-10-26 21:18:35'),
(35, 1, 'ORD-3CF7EC37D38787C3', 4300891411, NULL, NULL, 'Wojciech Radomski', 'wojciech@picabela.pl', '516194906', 'KRA010', 'medium', 59.99, 'PLN', 'paid', 'cancelled', '2025-10-27 11:58:56', '2025-10-27 11:59:03'),
(36, 1, 'ORD-8BE92403654E6E4C', 4300891711, '13633379', '600503007531612024676465', 'Wojciech Radomski', 'kontakt@picabela.pl', '516194906', 'PLPOPJAS11', 'medium', 59.99, 'PLN', 'paid', 'label_generated', '2025-10-27 12:26:28', '2025-10-27 12:26:40'),
(37, 1, 'ORD-9A8E93224841EC6B', 4300892379, '13633518', '600503007531612022506001', 'Wojciech Radomski', 'wojciech@picabela.pl', '516194906', 'PLPOPJAS11', 'medium', 59.99, 'PLN', 'paid', 'label_generated', '2025-10-27 13:19:28', '2025-10-27 13:19:41'),
(38, 1, 'ORD-75CC3F70E9390E7B', 4300892384, '13633527', '600503007531612022526280', 'Wojciech Radomski', 'wojciech@picabela.pl', '516194906', 'PLPOPGDA13', 'medium', 59.99, 'PLN', 'paid', 'label_generated', '2025-10-27 13:20:55', '2025-10-27 13:21:06'),
(39, 4, 'ORD-C9D5999515F0962F', NULL, NULL, NULL, 'Wojciech Radomski', 'wojciech@picabela.pl', '516194906', 'PLPOPKRO9', 'medium', 22.00, 'PLN', 'pending', 'new', '2025-10-27 14:19:14', '2025-10-27 14:19:14'),
(40, 1, 'ORD-B94C2DED3FC6290C', NULL, NULL, NULL, 'Marek ', 'mck@picabela.pl', '999999999', 'PLKRA09N', 'large', 62.99, 'PLN', 'pending', 'new', '2025-10-28 12:49:31', '2025-10-28 12:49:31'),
(41, 1, 'ORD-1741D25ABBD3BC6E', NULL, NULL, NULL, 'Janek Manek', 'mck@picabela.pl', '999999999', 'PLPLCIFRIENDLY', 'large', 62.99, 'PLN', 'pending', 'new', '2025-10-28 12:59:16', '2025-10-28 12:59:16'),
(42, 1, 'ORD-7A7C342A9E760C4D', NULL, NULL, NULL, 'Ola', 'mck@picabela.pl', '999999999', 'PLPOPKRO11', 'medium', 59.99, 'PLN', 'pending', 'new', '2025-10-28 13:03:01', '2025-10-28 13:03:01'),
(43, 1, 'ORD-9596114D4789D43A', NULL, NULL, NULL, 'Jola', 'mck@picabela.pl', '999999999', 'PLVRADM1', 'medium', 59.99, 'PLN', 'pending', 'new', '2025-10-28 13:05:27', '2025-10-28 13:05:27'),
(44, 1, 'ORD-13867FEAD4914389', 4300900981, '13636037', '600503996531612035892594', 'Magda', 'mck@picabela.pl', '999999999', 'PLKRA123APP', 'large', 62.99, 'PLN', 'paid', 'label_generated', '2025-10-28 13:12:09', '2025-10-28 13:12:21');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `settings`
--

CREATE TABLE `settings` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Zrzut danych tabeli `settings`
--

INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('email_from_address', 'support@butolog.pl'),
('email_from_name', 'BUTOLOG Naprawa Obuwia'),
('inpost_sandbox_enabled', 'true'),
('large_parcel_surcharge', '3.00'),
('p24_sandbox_enabled', 'true'),
('production_geowidget_token', ''),
('production_inpost_org_id', ''),
('production_inpost_token', ''),
('production_p24_api_key', ''),
('production_p24_crc_key', ''),
('production_p24_pos_id', ''),
('sandbox_geowidget_token', 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJkVzROZW9TeXk0OHpCOHg4emdZX2t5dFNiWHY3blZ0eFVGVFpzWV9TUFA4In0.eyJleHAiOjIwNTc5NjIxMjUsImlhdCI6MTc0MjYwMjEyNSwianRpIjoiZGE3ZDA1MDMtNThmZC00OWQwLWE3YWEtMmZlMzQ4YjcyODc0IiwiaXNzIjoiaHR0cHM6Ly9zYW5kYm94LWxvZ2luLmlucG9zdC5wbC9hdXRoL3JlYWxtcy9leHRlcm5hbCIsInN1YiI6ImY6N2ZiZjQxYmEtYTEzZC00MGQzLTk1ZjYtOThhMmIxYmFlNjdiOjR2UlJaSDZHNW1LUWdTa2FQXy0yWFVKd19pT0hvTUIwMDF1aGE4SE5aVzAiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJzaGlweCIsInNlc3Npb25fc3RhdGUiOiJlZTc2YTAyYi01YWMyLTQzOGYtOGZmNi1hOWQ5NzliMzFlODkiLCJzY29wZSI6Im9wZW5pZCBhcGk6YXBpcG9pbnRzIiwic2lkIjoiZWU3NmEwMmItNWFjMi00MzhmLThmZjYtYTlkOTc5YjMxZTg5IiwiYWxsb3dlZF9yZWZlcnJlcnMiOiJ0ZXN0LnBsIiwidXVpZCI6IjMxNzAwYmU3LTA2ZTAtNGVkZC05NTA1LTAzZjJhZjQ3M2QwMiJ9.GLoh6yMmqbC1tfI52hLVsxGIT80d0NQYlSU6NThVjM1TaEpCFGhQ_7F4skTjTGRX8CzdlUIkh4N0L-78KhboUGGaIn2DKc6bXMqB5YMOt_RMsDPXE3l0QGHrfndX9b9wxVdfDvGvM06R1Fcn_8l8alLRXrRhlY4GqWVzRzyC5rJjr4QkmPIZ2EvXB5DQoTStSUfcgWSzEhUGc499-TLsrztIb9DuyC_VSB3zo3D0bNX6NtbcYfOAK3Q4IGh2lj9DmSV9tW6aVj_QjHz-plstruTdg7vc6gK3vguPYY-55aQSJuO9ZHnx9rHvIcgdnx-7BVOBj84pviSqm2tiPcgZwg'),
('sandbox_inpost_org_id', '5134'),
('sandbox_inpost_token', 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJkVzROZW9TeXk0OHpCOHg4emdZX2t5dFNiWHY3blZ0eFVGVFpzWV9TUFA4In0.eyJleHAiOjIwNTc5NTk5MTcsImlhdCI6MTc0MjU5OTkxNywianRpIjoiOGZjMWZiNmQtNTJkOS00ZDNkLTkxZWQtNTA1YTU3MGNmODA3IiwiaXNzIjoiaHR0cHM6Ly9zYW5kYm94LWxvZ2luLmlucG9zdC5wbC9hdXRoL3JlYWxtcy9leHRlcm5hbCIsInN1YiI6ImY6N2ZiZjQxYmEtYTEzZC00MGQzLTk1ZjYtOThhMmIxYmFlNjdiOjR2UlJaSDZHNW1LUWdTa2FQXy0yWFVKd19pT0hvTUIwMDF1aGE4SE5aVzAiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJzaGlweCIsInNlc3Npb25fc3RhdGUiOiI0NzI1NjUwMi04NjIzLTQ2YmUtOTRmOC02NTA0YzZmNjk2MTMiLCJzY29wZSI6Im9wZW5pZCBhcGk6YXBpcG9pbnRzIGFwaTpzaGlweCIsInNpZCI6IjQ3MjU2NTAyLTg2MjMtNDZiZS05NGY4LTY1MDRjNmY2OTYxMyIsImFsbG93ZWRfcmVmZXJyZXJzIjoiIiwidXVpZCI6IjMxNzAwYmU3LTA2ZTAtNGVkZC05NTA1LTAzZjJhZjQ3M2QwMiIsImVtYWlsIjoia29udGFrdEBwaWNhYmVsYS5wbCJ9.gi0k1iTptAMC0iAILF9hfU5QsM3xClD59XcAs4Dax7FfGmoQTBlnsirBRO6bdVsAEaAN7eXB6kVzIc2om5bFocK8Xtk_z5ih9Piu-PmLKFp9FABmO1KUbq6ZprKBgZvHGEv01IIAgUvqKWfs_PldlCwwj9pBSjgp5IlGHiO0_xRX0kQiAd6RfIWLYuUi_zjTVltv1jS0eJ_eVmA2TOzxb2UF7mZrEpsIcoWbi_yba9g2GgJ46VxrRDI998TgBENPpMLFOECoG_-y60PF2nSU9Bl92qu0e6knxs_DxNYk_dScM0KKT842MorbniHGXcN-V8AfZzgvV1pxDLeqpb1IGA'),
('sandbox_p24_api_key', '404d485c25c140efee92436763a3fbe5'),
('sandbox_p24_crc_key', 'e0d7ac6125600939'),
('sandbox_p24_pos_id', '265781'),
('sender_name_override', ''),
('service_receiver_email', 'kontakt@butolog.pl'),
('service_receiver_locker', 'KRA012'),
('service_receiver_name', 'Profesjonalna Naprawa Obuwia BUTOLOG'),
('service_receiver_phone', '888888888');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indeksy dla tabeli `forms`
--
ALTER TABLE `forms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uuid` (`uuid`);

--
-- Indeksy dla tabeli `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `session_id` (`session_id`),
  ADD KEY `form_id` (`form_id`);

--
-- Indeksy dla tabeli `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `forms`
--
ALTER TABLE `forms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT dla tabeli `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `forms` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
